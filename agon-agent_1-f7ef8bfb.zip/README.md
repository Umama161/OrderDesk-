# OrderDesk — Phase 1

Turn messy WhatsApp / Instagram chat orders into a clean order list, track payments, and send a professional confirmation in under 30 seconds.

**Phase 1 scope (this build):** seller accounts, data model + RLS, Quick Add Order (paste → AI parse → editable form → save), order list/detail, payments, confirmations, free-plan usage counter, upgrade screen (Stripe placeholder), PWA, RTL + multi-currency.

**Stubbed for the next phase:** Today summary, Customers (history / total spent / re-order), catalog editing, Stripe checkout + webhook, phone (SMS OTP) sign-in.

---

## 1. Architecture overview

```
 Phone (installable PWA)                 Vercel                               Supabase
┌───────────────────────────┐   Bearer JWT   ┌──────────────────────────┐   ┌──────────────────────┐
│ React + TS + Tailwind SPA  │ ─────────────▶ │ /api/* serverless functions│──▶│ Postgres (+RLS)      │
│ supabase-js (auth only)    │                │  • verify JWT (auth.getUser)│   │ Auth (email, Google) │
│ service worker + manifest  │ ◀───── JSON ─── │  • scope every query by    │   └──────────────────────┘
└───────────────────────────┘                │    user_id                 │
                                              │  • /api/parse → Claude API │──▶ Anthropic Messages API
                                              │    (rule parser fallback)  │    (tool-use JSON output)
                                              └──────────────────────────┘
```

- **Frontend**: Vite + React 19 + TypeScript + Tailwind v4, React Router. Mobile-first, 48–56px tap targets, bottom nav, sticky totals bar. `supabase-js` is used only for sign-in/session; all data goes through `/api`.
- **API**: Vercel serverless functions in `/api`. Each request verifies the Supabase access token, then reads/writes with the service-role client **always filtered by `user_id`**. RLS policies (`auth.uid()::text = user_id`) protect every table as a second layer.
- **Quick Add parsing**: `/api/parse` sends the chat text, today's date and the seller's catalog to Claude with a forced `record_order` tool (structured JSON). If `ANTHROPIC_API_KEY` is missing or the call fails, a built-in rule parser handles common phrasing (names, quantities, weekdays/dates, addresses, "half now", "1500 advance", COD). Output is normalised (catalog price matching, `paid_fraction → amount`) and shown in an editable form — nothing is saved until the seller taps **Save order**.
- **Save order**: finds or creates the customer (by phone, then name), assigns a per-seller order number (#1001…), inserts order + items, and records the upfront payment.
- **Plan limits**: usage = orders created this calendar month (UTC). Enforced server-side in `POST /api/orders` (HTTP 402 `LIMIT_REACHED`), shown in the UI as a counter.
- **i18n / RTL**: `en`, `ur`, `ar` dictionaries; `<html dir>` switches automatically, layouts use logical properties (`ps-`, `me-`, `start-`). Money uses `Intl.NumberFormat` with the seller currency (16 currencies) and Latin digits.
- **PWA**: `manifest.webmanifest`, maskable icons, `sw.js` (network-first shell, stale-while-revalidate assets, never caches `/api`). Install prompt in **More**.

> **Stack note:** you asked for Next.js App Router. This workspace ships Vite + React + Vercel functions, so Phase 1 uses that, with the same Supabase/Vercel setup. Moving to Next.js is mechanical: `src/pages/*` → `app/**/page.tsx` (client components), `api/*.js` → `app/api/**/route.ts`. `src/lib` and `src/components` move over unchanged.

## 2. Folder structure

```
.
├── api/                      # Vercel serverless functions
│   ├── _auth.js              # CORS, JWT verification, usage counter, FREE_MONTHLY_LIMIT
│   ├── _match.js             # catalog matching + parsed-order normaliser
│   ├── _rules.js             # offline rule-based chat parser (fallback)
│   ├── db-client.js          # Supabase service client (pre-provided)
│   ├── db-wake.js            # auto-resume paused DB (pre-provided)
│   ├── seller.js             # GET/POST/PUT seller profile + usage
│   ├── parse.js              # POST chat → structured order (Claude)
│   ├── orders.js             # list/detail/create/update status/delete
│   ├── payments.js           # record/remove payments (recalculates amount_paid)
│   ├── products.js           # catalog (read-only in Phase 1)
│   └── checkout.js           # Stripe checkout placeholder
├── public/
│   ├── manifest.webmanifest, sw.js, favicon.svg, icons/
├── src/
│   ├── contexts/             # AuthContext, SellerContext (profile, usage, i18n, dir)
│   ├── components/           # AppShell, Guards, OrderForm, PaymentSheet, UsageMeter, ui
│   ├── lib/                  # api, supabase, googleAuth, i18n, format, confirmation, pwa, types
│   ├── pages/                # Login, Onboarding, Orders, QuickAdd, OrderDetail, Upgrade, More, Catalog, ComingSoon
│   ├── App.tsx, main.tsx, index.css
├── supabase/schema.sql       # tables, indexes, constraints, RLS
└── vercel.json               # env + SPA rewrite
```

## 3. Data model

| Table | Key columns |
|---|---|
| `sellers` | `user_id` (PK), shop_name, phone, currency, locale, plan (`free`/`pro`) |
| `customers` | id, user_id, name, phone, address |
| `products` | id, user_id, name, price, unit, active |
| `orders` | id, user_id, customer_id → customers, order_number, status, delivery_date, delivery_address, notes, raw_message, total, amount_paid, currency |
| `order_items` | id, user_id, order_id → orders (cascade), product_id → products, name, quantity, unit_price, line_total |
| `payments` | id, user_id, order_id → orders (cascade), amount, method, note, paid_at |

Full SQL with constraints, indexes and RLS: `supabase/schema.sql`.

## 4. Setup guide

### Environment variables

| Variable | Where | Purpose |
|---|---|---|
| `VITE_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_URL` | client + server | Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` | client + server | public anon key (auth) |
| `SUPABASE_SERVICE_ROLE_KEY` | **server only** | API data access (never expose to the browser) |
| `ANTHROPIC_API_KEY` | **server only** | Claude parsing for Quick Add (optional — falls back to rules) |
| `ANTHROPIC_MODEL` | server, optional | defaults to `claude-haiku-5-5` (fast, low cost for extraction) |
| `VITE_GOOGLE_CLIENT_ID`, `VITE_GOOGLE_AUTH_PROXY` | client, optional | Google sign-in |
| `STRIPE_SECRET_KEY`, `STRIPE_PRICE_ID`, `STRIPE_WEBHOOK_SECRET` | server, next phase | Pro checkout (not used yet) |

### Local

1. Create a Supabase project. In **SQL Editor** run `supabase/schema.sql`.
2. In **Authentication → Providers** enable Email (optionally turn off "Confirm email" while testing).
3. Copy the URL, anon key and service-role key into `.env`.
4. `npm install` then `npx vercel dev` (runs the Vite app and `/api` functions together).

### Deploy to Vercel

1. Push the repo to GitHub and **Import Project** in Vercel (framework preset: Vite; build `npm run build`; output `dist`).
2. Add the environment variables above in **Settings → Environment Variables** (mark service-role and Anthropic keys as server-only, without the `VITE_` prefix).
3. Deploy. `vercel.json` rewrites every non-`/api` path to `index.html` so deep links work; `sw.js` and the manifest are served as static files.
4. In Supabase **Authentication → URL Configuration**, add your Vercel domain to Site URL / Redirect URLs.
5. Open the site on a phone → **More → Install OrderDesk** (Android) or **Share → Add to Home Screen** (iPhone).

### Phone sign-in (not wired yet)

Supabase supports phone OTP (`supabase.auth.signInWithOtp({ phone })`) once an SMS provider (Twilio, MessageBird, Vonage) is configured under **Authentication → Providers → Phone**. Phase 1 ships email/password + Google; the seller model is keyed on `auth.uid()`, so phone accounts slot in without schema changes.

## 5. Testing checklist (Phase 1)

- Sign in with the demo account `demo@orderdesk.app` / `orderdesk123` (seeded with a PKR bakery, 8 products, 7 orders) or create a new account → onboarding.
- **Quick Add**: tap an example, then **Read order**, edit and save. You land on the order with a ready confirmation; **Send on WhatsApp** or **Copy** marks it Confirmed.
- Record or remove a payment; badges and balances update.
- Change language to اردو / العربية in **More**: layout flips to RTL, confirmation text is localised.
- Usage counter: the 31st order in a month on the free plan is blocked with an upgrade prompt.

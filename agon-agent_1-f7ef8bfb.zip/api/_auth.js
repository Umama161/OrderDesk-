import supabase from './db-client.js';

export const FREE_MONTHLY_LIMIT = 30;

export function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return true;
  }
  return false;
}

/**
 * Verifies the Supabase access token from the Authorization header.
 * Every query in the API is additionally scoped with .eq('user_id', user.id),
 * and RLS policies (auth.uid() = user_id) protect direct client access.
 */
export async function requireUser(req, res) {
  const header = req.headers.authorization || '';
  const token = header.replace(/^Bearer\s+/i, '').trim();
  if (!token || token === 'undefined' || token === 'null') {
    res.status(401).json({ error: 'Please sign in again.' });
    return null;
  }
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) {
    res.status(401).json({ error: 'Your session expired. Please sign in again.' });
    return null;
  }
  return data.user;
}

export function monthBounds() {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { start: start.toISOString(), next: next.toISOString() };
}

export async function getUsage(userId, plan) {
  const { start, next } = monthBounds();
  const { count, error } = await supabase
    .from('orders')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .gte('created_at', start);
  if (error) throw error;
  return {
    used: count || 0,
    limit: plan === 'pro' ? null : FREE_MONTHLY_LIMIT,
    plan: plan || 'free',
    resets_at: next,
  };
}

export async function getSeller(userId) {
  const { data, error } = await supabase
    .from('sellers')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

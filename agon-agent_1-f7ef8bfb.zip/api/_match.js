// Shared helpers: product matching + normalising a parsed order.

const FILLER = new Set(['of', 'the', 'a', 'an', 'with', 'and', 'pcs', 'pc', 'piece', 'pieces']);

export function singular(word) {
  if (word.length <= 3) return word;
  if (word.endsWith('ies')) return word.slice(0, -3) + 'y';
  if (/(ches|shes|xes|sses)$/.test(word)) return word.slice(0, -2);
  if (word.endsWith('s') && !word.endsWith('ss')) return word.slice(0, -1);
  return word;
}

export function tokens(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[()\[\],.:;!?/]/g, ' ')
    .split(/\s+/)
    .filter((w) => w && !FILLER.has(w) && !/^\d+$/.test(w))
    .map(singular);
}

/** Dice-coefficient match of an item name against the seller's catalog. */
export function matchProduct(name, products) {
  const q = tokens(name);
  if (!q.length || !products?.length) return null;
  let best = null;
  let bestScore = 0;
  for (const p of products) {
    const pt = tokens(p.name);
    if (!pt.length) continue;
    const set = new Set(pt);
    const inter = q.filter((w) => set.has(w)).length;
    const score = (2 * inter) / (q.length + pt.length);
    if (score > bestScore) {
      bestScore = score;
      best = p;
    }
  }
  return bestScore >= 0.5 ? best : null;
}

function titleCase(s) {
  return s.replace(/(^|\s)(\p{Ll})/gu, (_m, sp, ch) => sp + ch.toUpperCase());
}

function num(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(/,/g, ''));
  return Number.isFinite(n) ? n : null;
}

/** Normalise raw parser output (Claude or rules) into the shape the form expects. */
export function normalizeParsed(raw, products) {
  const warnings = [];
  const items = (Array.isArray(raw?.items) ? raw.items : [])
    .filter((i) => i && String(i.name || '').trim())
    .map((i) => {
      let name = String(i.name).trim();
      const quantity = Math.max(num(i.quantity) ?? 1, 0) || 1;
      let unit_price = num(i.unit_price);
      let product = null;
      if (i.product_id) product = products.find((p) => Number(p.id) === Number(i.product_id)) || null;
      if (!product) product = matchProduct(name, products);
      if (product) {
        name = product.name;
        if (unit_price === null) unit_price = Number(product.price);
      } else {
        name = titleCase(name);
      }
      return { product_id: product ? product.id : null, name, quantity, unit_price };
    });

  const total = items.reduce((s, i) => s + i.quantity * (i.unit_price ?? 0), 0);
  let amount_paid = num(raw?.amount_paid);
  const fraction = num(raw?.paid_fraction);
  if (amount_paid === null && fraction !== null && fraction > 0) {
    amount_paid = Math.round(total * Math.min(fraction, 1));
  }
  if (amount_paid === null || amount_paid < 0) amount_paid = 0;

  const date = typeof raw?.delivery_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.delivery_date)
    ? raw.delivery_date
    : '';

  let phone = String(raw?.phone || '').replace(/[^\d+]/g, '');
  if (phone.replace(/\D/g, '').length < 7) phone = '';

  if (!raw?.customer_name) warnings.push('No customer name found');
  if (!items.length) warnings.push('No items found');
  if (items.some((i) => i.unit_price === null)) warnings.push('Some items need a price');

  return {
    order: {
      customer_name: String(raw?.customer_name || '').trim(),
      phone,
      items,
      delivery_date: date,
      delivery_address: String(raw?.delivery_address || '').trim(),
      amount_paid,
      notes: String(raw?.notes || '').trim(),
    },
    warnings,
  };
}

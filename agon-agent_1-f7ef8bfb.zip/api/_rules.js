// Offline rule-based parser used when ANTHROPIC_API_KEY is not configured
// (or the Claude call fails). Handles the most common chat-order phrasing.
import { matchProduct } from './_match.js';

const WEEKDAYS = [
  ['sun', 'sunday'], ['mon', 'monday'], ['tue', 'tues', 'tuesday'], ['wed', 'wednesday'],
  ['thu', 'thur', 'thurs', 'thursday'], ['fri', 'friday'], ['sat', 'saturday'],
];
const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const MONTH_WORDS = ['january', 'february', 'march', 'april', 'june', 'july', 'august', 'september', 'sept', 'october', 'november', 'december', ...MONTHS];
const WORD_NUMS = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, a: 1, an: 1 };
const STOP = [
  'and', 'deliver', 'delivery', 'delivered', 'for', 'on', 'by', 'to', 'at', 'will', 'pay', 'paid', 'paying',
  'with', 'plus', 'also', 'please', 'pls', 'plz', 'today', 'tomorrow', 'tonight', 'before', 'after', 'cod',
  'cash', 'half', 'address', 'each', 'from', 'in', 'send', 'sent', 'advance', 'need', 'needs', 'want', 'wants',
  'is', 'are', 'the', 'but', 'or', 'asap', 'this', 'next', 'thanks', 'thank', 'until', 'till', 'around', 'pickup',
  ...WEEKDAYS.flat(), ...MONTH_WORDS,
];
const UNITS = ['kg', 'g', 'gm', 'gms', 'gram', 'grams', 'lb', 'lbs', 'pound', 'pounds', 'ml', 'l', 'litre', 'liter', 'inch', 'inches'];
const SKIP_FIRST = ['rs', 'rupees', 'pkr', 'inr', 'aed', 'sar', 'usd', 'dollars', 'pm', 'am', 'st', 'nd', 'rd', 'th', 'days', 'day', 'hours', 'hrs', 'hour', 'mins', 'minutes', 'percent', 'k', 'pcs'];

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const STOP_ALT = STOP.map(esc).join('|');
const WORD = "[\\p{L}][\\p{L}'’\\-]*";
const NAME_WORD = "\\p{Lu}[\\p{L}'’\\-]+";

function isoFromUTC(d) {
  return d.toISOString().slice(0, 10);
}

function parseDate(text, today) {
  const base = new Date(`${today}T00:00:00Z`);
  if (Number.isNaN(base.getTime())) return '';
  const lower = text.toLowerCase();
  const plus = (n) => { const d = new Date(base); d.setUTCDate(d.getUTCDate() + n); return isoFromUTC(d); };

  if (/\b(today|tonight|aaj)\b/.test(lower)) return plus(0);
  if (/\b(tomorrow|tmrw|tmr|kal)\b/.test(lower)) return plus(1);
  if (/\bday after tomorrow\b/.test(lower)) return plus(2);

  // 25 Nov / 25th November / Nov 25
  const monthAlt = MONTH_WORDS.map(esc).join('|');
  let m = lower.match(new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${monthAlt})\\b`));
  let day; let month;
  if (m) { day = Number(m[1]); month = MONTHS.indexOf(m[2].slice(0, 3)); }
  if (!m) {
    m = lower.match(new RegExp(`\\b(${monthAlt})\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b`));
    if (m) { day = Number(m[2]); month = MONTHS.indexOf(m[1].slice(0, 3)); }
  }
  if (m && day >= 1 && day <= 31 && month >= 0) {
    let year = base.getUTCFullYear();
    let d = new Date(Date.UTC(year, month, day));
    if (d < base) d = new Date(Date.UTC(year + 1, month, day));
    return isoFromUTC(d);
  }

  const wdAlt = WEEKDAYS.flat().sort((a, b) => b.length - a.length).join('|');
  const w = lower.match(new RegExp(`\\b(next\\s+)?(${wdAlt})\\b`));
  if (w) {
    const idx = WEEKDAYS.findIndex((names) => names.includes(w[2]));
    let diff = (idx - base.getUTCDay() + 7) % 7;
    if (w[1] && diff === 0) diff = 7;
    return plus(diff);
  }

  // 25/11 or 25.11.2026 (not part of an address like G-11/2)
  const n = lower.match(/(?<![\w\-/])(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2,4}))?(?![\w/])/);
  if (n && Number(n[2]) >= 1 && Number(n[2]) <= 12 && Number(n[1]) >= 1 && Number(n[1]) <= 31) {
    const year = base.getUTCFullYear();
    let d = new Date(Date.UTC(year, Number(n[2]) - 1, Number(n[1])));
    if (d < base) d = new Date(Date.UTC(year + 1, Number(n[2]) - 1, Number(n[1])));
    return isoFromUTC(d);
  }
  return '';
}

function parsePhone(text) {
  for (const m of text.matchAll(/\+?\d[\d\s-]{7,16}\d/g)) {
    const digits = m[0].replace(/\D/g, '');
    if (digits.length >= 10 && digits.length <= 15) return { phone: m[0].replace(/[\s-]/g, ''), raw: m[0] };
  }
  return { phone: '', raw: '' };
}

function parseName(text) {
  const verbs = '(?:wants?|needs?|would like|wud like|ordered|orders?|is ordering|asked for|asking for|has ordered|booked|wants to order)';
  const patterns = [
    new RegExp(`(?:^|[.!?\\n,]\\s*)(?:hi|hello|salam|assalam[ou]?\\s*alaikum|aoa)?[,!\\s]*(${NAME_WORD}(?:\\s+${NAME_WORD})?)\\s+${verbs}\\b`, 'u'),
    new RegExp(`(?:this is|i am|i'm|im|my name is|name\\s*[:\\-]|customer\\s*[:\\-])\\s*(${NAME_WORD}(?:\\s+${NAME_WORD})?)`, 'iu'),
    new RegExp(`(?:[Oo]rder|[Cc]ake|[Dd]elivery|[Bb]ooking)\\s+for\\s+(${NAME_WORD}(?:\\s+${NAME_WORD})?)`, 'u'),
    new RegExp(`(?:^|[.!?,\\n]\\s*)(${NAME_WORD})\\s+here\\b`, 'u'),
    new RegExp(`^\\s*(${NAME_WORD})\\s*[:\\-]`, 'u'),
  ];
  const banned = new Set(['hi', 'hello', 'salam', 'please', 'order', 'need', 'deliver', 'delivery', 'i', 'we', 'new', 'customer', 'name', 'can']);
  for (const re of patterns) {
    const m = text.match(re);
    if (m && m[1]) {
      const words = m[1].split(/\s+/).filter((w) => !banned.has(w.toLowerCase()) && !STOP.includes(w.toLowerCase()));
      if (words.length) return words.join(' ');
    }
  }
  return '';
}

function parseAddress(text) {
  const wdAlt = WEEKDAYS.flat().join('|');
  const patterns = [
    /(?:address|addr|location|loc)\s*(?:is\s*)?[:\-]?\s*([^\n;]+?)(?=[.;\n](?:\s|$)|,\s*(?:sent|paid|will|cash|cod|pay|deliver|advance)|$)/i,
    /\b(?:deliver(?:y|ed)?|send|drop|ship)\b[^,.;\n]*?\b(?:to|at)\s+([^,;\n]+?)(?=[,;\n]|\.(?:\s|$)|$)/i,
    new RegExp(`\\b(?:today|tomorrow|tonight|${wdAlt})\\b\\s+(?:to|at|in)\\s+([^,;\\n]+?)(?=[,;\\n]|\\.(?:\\s|$)|$)`, 'i'),
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m && m[1]) {
      const addr = m[1].split(/\s+(?:will|and pay|pay|paid|cash on|cod|by|before|after|around|sent|advance)\b/i)[0].trim();
      if (addr && !/^\d+$/.test(addr)) return addr;
    }
  }
  return '';
}

function parsePayment(text) {
  const lower = text.toLowerCase();
  if (/\b(cash on delivery|cod|pay (?:on|at) delivery|will pay later|pay later)\b/.test(lower)) return { amount_paid: 0, paid_fraction: null };
  if (/\bhalf\b/.test(lower) && /\b(pay|paid|advance|now|sent|transfer)/.test(lower)) return { amount_paid: null, paid_fraction: 0.5 };
  if (/\b(paid in full|full payment|fully paid|paid full|already paid|paid the full|full advance)\b/.test(lower)) return { amount_paid: null, paid_fraction: 1 };
  let m = lower.match(/\b(?:advance|paid|sent|deposit(?:ed)?|transferred|paying|pay)\b\D{0,14}?(\d[\d,]*(?:\.\d+)?)/);
  if (m) return { amount_paid: Number(m[1].replace(/,/g, '')), paid_fraction: null };
  m = lower.match(/(\d[\d,]*(?:\.\d+)?)\s*(?:rs\.?|pkr|aed|sar|inr|usd|\$)?\s*(?:advance|paid|deposit|sent)\b/);
  if (m) return { amount_paid: Number(m[1].replace(/,/g, '')), paid_fraction: null };
  return { amount_paid: null, paid_fraction: null };
}

function parseItems(text, products) {
  const NUM = `(?:(\\d+(?:\\.\\d+)?)\\s*|(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|an?)\\s+)`;
  const NAMEPART = `((?!(?:${STOP_ALT})\\b)${WORD}(?:\\s+(?!(?:${STOP_ALT})\\b)${WORD}){0,4})`;
  const PRICE = `(?:\\s*(?:@|for|at|x|×|-)\\s*(?:rs\\.?|pkr|aed|sar|inr|usd|\\$|₹|£|€)?\\s*(\\d[\\d,]*(?:\\.\\d+)?)(?:\\s*(?:each|per|/-))?)?`;
  const re = new RegExp(`(?<![\\p{L}\\p{N}+\\-/.#])${NUM}(?:[x×]\\s+)?${NAMEPART}${PRICE}`, 'giu');
  const items = [];
  for (const m of text.matchAll(re)) {
    const before = text.slice(Math.max(0, m.index - 14), m.index).toLowerCase();
    if (/(?:rs\.?|pkr|paid|pay|sent|advance|deposit|total|house|street|st\.?|plot|flat|block|sector|phase|no\.?|#|apt|floor)\s*$/.test(before)) continue;
    const qtyRaw = m[1] ?? m[2];
    const isWordNum = !m[1];
    const quantity = isWordNum ? WORD_NUMS[qtyRaw.toLowerCase()] : Number(qtyRaw);
    let name = m[3].trim();
    const first = name.split(/\s+/)[0].toLowerCase();
    if (UNITS.includes(first)) {
      const prev = items[items.length - 1];
      if (prev) prev.spec = `${qtyRaw}${first}`;
      continue;
    }
    if (SKIP_FIRST.includes(first)) continue;
    if (isWordNum && /^an?$/i.test(qtyRaw) && !matchProduct(name, products)) continue;
    if (!quantity || quantity > 1000) continue;
    items.push({
      name,
      quantity,
      unit_price: m[4] ? Number(m[4].replace(/,/g, '')) : null,
    });
  }
  return items;
}

export function ruleParse(message, products, today) {
  const text = String(message || '').replace(/[\t ]+/g, ' ').trim();
  const { phone, raw: phoneRaw } = parsePhone(text);
  const delivery_address = parseAddress(text);
  let itemText = text;
  if (phoneRaw) itemText = itemText.replace(phoneRaw, ' ');
  if (delivery_address) itemText = itemText.replace(delivery_address, ' ');
  const pay = parsePayment(text);
  let dateText = text;
  if (phoneRaw) dateText = dateText.replace(phoneRaw, ' ');
  if (delivery_address) dateText = dateText.replace(delivery_address, ' ');
  const items = parseItems(itemText, products);
  const notes = items.filter((i) => i.spec).map((i) => `${i.name}: ${i.spec}`).join('; ');
  return {
    customer_name: parseName(text),
    phone,
    items: items.map(({ spec: _spec, ...rest }) => rest),
    delivery_date: parseDate(dateText, today),
    delivery_address,
    amount_paid: pay.amount_paid,
    paid_fraction: pay.paid_fraction,
    notes,
  };
}

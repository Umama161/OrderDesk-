import { cors, requireUser } from './_auth.js';

// Stripe Checkout placeholder (Phase 1).
// Next phase: create a Checkout Session with STRIPE_SECRET_KEY + STRIPE_PRICE_ID,
// return session.url, and flip sellers.plan to 'pro' from a Stripe webhook.
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const user = await requireUser(req, res);
  if (!user) return;
  return res.status(200).json({
    placeholder: true,
    message: 'Stripe checkout isn’t connected yet. In the next phase this button opens a secure Stripe payment page and unlocks Pro automatically.',
  });
}

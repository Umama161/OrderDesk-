import supabase from './db-client.js';
import { cors, requireUser, getSeller, getUsage } from './_auth.js';

const STATUSES = ['new', 'confirmed', 'delivered', 'cancelled'];
const METHODS = ['cash', 'bank', 'card', 'wallet', 'other'];

const toNum = (v) => {
  const n = Number(String(v ?? '').replace(/,/g, ''));
  return Number.isFinite(n) ? n : NaN;
};
const round2 = (n) => Math.round(n * 100) / 100;

async function findOrCreateCustomer(userId, { name, phone, address }) {
  const cleanPhone = phone ? phone.replace(/[^\d+]/g, '') : '';
  let existing = null;
  if (cleanPhone) {
    const { data, error } = await supabase
      .from('customers').select('*').eq('user_id', userId).eq('phone', cleanPhone).limit(1);
    if (error) throw error;
    existing = data?.[0] || null;
  }
  if (!existing) {
    const safe = name.replace(/[%_\\]/g, (c) => `\\${c}`);
    const { data, error } = await supabase
      .from('customers').select('*').eq('user_id', userId).ilike('name', safe).limit(1);
    if (error) throw error;
    const candidate = data?.[0] || null;
    // Only merge by name when phones don't conflict.
    if (candidate && (!cleanPhone || !candidate.phone || candidate.phone === cleanPhone)) existing = candidate;
  }
  if (existing) {
    const patch = {};
    if (cleanPhone && !existing.phone) patch.phone = cleanPhone;
    if (address) patch.address = address;
    if (Object.keys(patch).length) {
      const { data, error } = await supabase
        .from('customers').update(patch).eq('id', existing.id).eq('user_id', userId).select('*').single();
      if (error) throw error;
      return data;
    }
    return existing;
  }
  const { data, error } = await supabase
    .from('customers')
    .insert({ user_id: userId, name, phone: cleanPhone || null, address: address || null })
    .select('*')
    .single();
  if (error) throw error;
  return data;
}

export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const user = await requireUser(req, res);
    if (!user) return;

    if (req.method === 'GET') {
      const { id } = req.query;
      if (id) {
        const { data, error } = await supabase
          .from('orders')
          .select('*, customers(*), order_items(*), payments(*)')
          .eq('user_id', user.id)
          .eq('id', id)
          .maybeSingle();
        if (error) throw error;
        if (!data) return res.status(404).json({ error: 'Order not found.' });
        data.order_items?.sort((a, b) => a.id - b.id);
        data.payments?.sort((a, b) => new Date(a.paid_at) - new Date(b.paid_at));
        return res.status(200).json(data);
      }
      const { data, error } = await supabase
        .from('orders')
        .select('*, customers(id, name, phone), order_items(id, name, quantity)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(300);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const seller = await getSeller(user.id);
      if (!seller) return res.status(400).json({ error: 'Finish setting up your shop first.' });

      const usage = await getUsage(user.id, seller.plan);
      if (usage.limit !== null && usage.used >= usage.limit) {
        return res.status(402).json({
          error: `You've reached the free plan limit of ${usage.limit} orders this month.`,
          code: 'LIMIT_REACHED',
        });
      }

      const b = req.body || {};
      const name = String(b.customer?.name || '').trim().slice(0, 80);
      if (!name) return res.status(400).json({ error: 'Customer name is required.' });

      const items = (Array.isArray(b.items) ? b.items : [])
        .map((i) => ({
          product_id: i.product_id ? Number(i.product_id) : null,
          name: String(i.name || '').trim().slice(0, 120),
          quantity: toNum(i.quantity),
          unit_price: toNum(i.unit_price),
        }))
        .filter((i) => i.name);
      if (!items.length) return res.status(400).json({ error: 'Add at least one item.' });
      if (items.some((i) => !(i.quantity > 0) || !(i.unit_price >= 0))) {
        return res.status(400).json({ error: 'Every item needs a quantity above 0 and a price.' });
      }

      const total = round2(items.reduce((s, i) => s + i.quantity * i.unit_price, 0));
      const amountPaid = b.amount_paid ? round2(toNum(b.amount_paid)) : 0;
      if (!(amountPaid >= 0)) return res.status(400).json({ error: 'Paid amount is not valid.' });
      if (amountPaid > total) return res.status(400).json({ error: 'Paid amount can’t be more than the total.' });
      const deliveryDate = /^\d{4}-\d{2}-\d{2}$/.test(b.delivery_date || '') ? b.delivery_date : null;
      const address = String(b.delivery_address || '').trim().slice(0, 300) || null;
      const method = METHODS.includes(b.payment_method) ? b.payment_method : 'cash';

      const customer = await findOrCreateCustomer(user.id, {
        name,
        phone: String(b.customer?.phone || '').trim(),
        address,
      });

      const { data: last, error: lastErr } = await supabase
        .from('orders').select('order_number').eq('user_id', user.id)
        .order('order_number', { ascending: false }).limit(1);
      if (lastErr) throw lastErr;
      const orderNumber = (last?.[0]?.order_number || 1000) + 1;

      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          customer_id: customer.id,
          order_number: orderNumber,
          status: 'new',
          delivery_date: deliveryDate,
          delivery_address: address,
          notes: String(b.notes || '').trim().slice(0, 1000) || null,
          raw_message: String(b.raw_message || '').trim().slice(0, 4000) || null,
          total,
          amount_paid: amountPaid,
          currency: seller.currency,
        })
        .select('*')
        .single();
      if (orderErr) throw orderErr;

      const { error: itemsErr } = await supabase.from('order_items').insert(
        items.map((i) => ({
          user_id: user.id,
          order_id: order.id,
          product_id: i.product_id,
          name: i.name,
          quantity: i.quantity,
          unit_price: i.unit_price,
          line_total: round2(i.quantity * i.unit_price),
        })),
      );
      if (itemsErr) {
        await supabase.from('orders').delete().eq('id', order.id);
        throw itemsErr;
      }

      if (amountPaid > 0) {
        const { error: payErr } = await supabase.from('payments').insert({
          user_id: user.id,
          order_id: order.id,
          amount: amountPaid,
          method,
          note: 'Paid when ordering',
        });
        if (payErr) throw payErr;
      }

      return res.status(201).json(order);
    }

    if (req.method === 'PUT') {
      const { id, status, delivery_date, delivery_address, notes } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Order id is required.' });
      const patch = {};
      if (status !== undefined) {
        if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Unknown status.' });
        patch.status = status;
      }
      if (delivery_date !== undefined) patch.delivery_date = /^\d{4}-\d{2}-\d{2}$/.test(delivery_date || '') ? delivery_date : null;
      if (delivery_address !== undefined) patch.delivery_address = String(delivery_address || '').trim() || null;
      if (notes !== undefined) patch.notes = String(notes || '').trim() || null;
      if (!Object.keys(patch).length) return res.status(400).json({ error: 'Nothing to update.' });
      const { data, error } = await supabase
        .from('orders').update(patch).eq('id', id).eq('user_id', user.id).select('*').single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Order id is required.' });
      const { error } = await supabase.from('orders').delete().eq('id', id).eq('user_id', user.id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

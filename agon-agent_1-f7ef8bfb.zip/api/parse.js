import supabase from './db-client.js';
import { cors, requireUser, getSeller } from './_auth.js';
import { ruleParse } from './_rules.js';
import { normalizeParsed } from './_match.js';

const DEFAULT_MODEL = 'claude-haiku-5-5';

const ORDER_TOOL = {
  name: 'record_order',
  description: 'Record the structured order extracted from the chat message.',
  input_schema: {
    type: 'object',
    properties: {
      customer_name: { type: ['string', 'null'], description: 'Name of the customer placing the order. Null if not mentioned.' },
      phone: { type: ['string', 'null'], description: 'Phone number exactly as written, if present. Never invent one.' },
      items: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Item name. Use the exact catalog name when it clearly matches.' },
            product_id: { type: ['integer', 'null'], description: 'Catalog id when the item matches a catalog product, otherwise null.' },
            quantity: { type: 'number', description: 'Quantity ordered (default 1).' },
            unit_price: { type: ['number', 'null'], description: 'Price per unit. Use the price stated in the message, else the catalog price, else null.' },
          },
          required: ['name', 'quantity'],
        },
      },
      delivery_date: { type: ['string', 'null'], description: 'Delivery date as YYYY-MM-DD resolved relative to today, or null.' },
      delivery_address: { type: ['string', 'null'], description: 'Delivery address or area exactly as written, or null.' },
      amount_paid: { type: ['number', 'null'], description: 'Explicit amount already paid / being paid now, in the seller currency. Null if expressed as a fraction or not mentioned.' },
      paid_fraction: { type: ['number', 'null'], description: 'Fraction of the total paid now when expressed relatively (half = 0.5, full = 1). Null otherwise.' },
      notes: { type: ['string', 'null'], description: 'Other important details: flavours, message on cake, time of delivery, special requests. Short.' },
    },
    required: ['items'],
  },
};

const SYSTEM = `You extract orders from informal chat messages that customers send to small home businesses on WhatsApp and Instagram.
Messages can be in English, Urdu, Hindi, Arabic or a mix (including Roman Urdu like "kal" = tomorrow, "aadha" = half).
Always call the record_order tool exactly once.
Rules:
- Never invent data. If something is not in the message, use null.
- Match items to the seller's catalog when clearly the same product and copy its id, name and price.
- If the message states a price, use it as the unit price (divide a line total by quantity).
- Resolve relative dates ("Friday", "tomorrow", "next Monday") against the provided date of today. A bare weekday means the next occurrence (today if it is that weekday).
- "will pay half now" => paid_fraction 0.5. "paid 1500 advance" => amount_paid 1500. "cash on delivery" => amount_paid 0.`;

async function claudeParse({ message, products, today, currency }) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return null;
  const weekday = new Date(`${today}T00:00:00Z`).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
  const catalog = products.length
    ? products.map((p) => `- id ${p.id}: ${p.name} — ${p.price} ${currency}`).join('\n')
    : '(no catalog products yet)';
  const userContent = `Today is ${today} (${weekday}). Seller currency: ${currency}.\n\nSeller catalog:\n${catalog}\n\nChat message:\n"""\n${message}\n"""`;

  const call = async (forceTool) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'content-type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: process.env.ANTHROPIC_MODEL || DEFAULT_MODEL,
          max_tokens: 1500,
          system: SYSTEM,
          tools: [ORDER_TOOL],
          ...(forceTool ? { tool_choice: { type: 'tool', name: 'record_order' } } : {}),
          messages: [{ role: 'user', content: userContent }],
        }),
      });
      const json = await r.json().catch(() => null);
      return { ok: r.ok, status: r.status, json };
    } finally {
      clearTimeout(timer);
    }
  };

  let result = await call(true);
  if (!result.ok && result.status === 400) result = await call(false);
  if (!result.ok) {
    throw new Error(result.json?.error?.message || `Claude API error ${result.status}`);
  }
  const toolUse = result.json?.content?.find((c) => c.type === 'tool_use');
  if (toolUse?.input) return toolUse.input;
  const text = result.json?.content?.find((c) => c.type === 'text')?.text || '';
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (jsonMatch) return JSON.parse(jsonMatch[0]);
  throw new Error('Claude did not return an order');
}

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = await requireUser(req, res);
    if (!user) return;

    const message = String(req.body?.message || '').trim();
    if (!message) return res.status(400).json({ error: 'Paste a chat message first.' });
    if (message.length > 4000) return res.status(400).json({ error: 'That message is too long. Paste just the order part.' });

    const today = /^\d{4}-\d{2}-\d{2}$/.test(req.body?.today || '')
      ? req.body.today
      : new Date().toISOString().slice(0, 10);

    const seller = await getSeller(user.id);
    const currency = seller?.currency || 'USD';

    const { data: products, error } = await supabase
      .from('products')
      .select('id, name, price')
      .eq('user_id', user.id)
      .eq('active', true)
      .order('name');
    if (error) throw error;

    let raw = null;
    let source = 'rules';
    let notice = '';
    try {
      raw = await claudeParse({ message, products: products || [], today, currency });
      if (raw) source = 'claude';
    } catch (err) {
      console.error('Claude parse failed, using rules:', err.message);
      notice = 'AI reader was unavailable, used quick rules instead.';
    }
    if (!raw) raw = ruleParse(message, products || [], today);

    const { order, warnings } = normalizeParsed(raw, products || []);
    return res.status(200).json({ order, warnings, source, notice });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

import supabase from './db-client.js';
import { cors, requireUser } from './_auth.js';

const METHODS = ['cash', 'bank', 'card', 'wallet', 'other'];
const round2 = (n) => Math.round(n * 100) / 100;

async function recalc(userId, orderId) {
  const { data, error } = await supabase
    .from('payments').select('amount').eq('user_id', userId).eq('order_id', orderId);
  if (error) throw error;
  const paid = round2((data || []).reduce((s, p) => s + Number(p.amount), 0));
  const { data: order, error: updErr } = await supabase
    .from('orders').update({ amount_paid: paid }).eq('id', orderId).eq('user_id', userId).select('*').single();
  if (updErr) throw updErr;
  return order;
}

export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const user = await requireUser(req, res);
    if (!user) return;

    if (req.method === 'POST') {
      const { order_id, amount, method, note } = req.body || {};
      const value = round2(Number(amount));
      if (!order_id) return res.status(400).json({ error: 'Order id is required.' });
      if (!(value > 0)) return res.status(400).json({ error: 'Enter an amount above 0.' });

      const { data: order, error: oErr } = await supabase
        .from('orders').select('id, total, amount_paid').eq('id', order_id).eq('user_id', user.id).maybeSingle();
      if (oErr) throw oErr;
      if (!order) return res.status(404).json({ error: 'Order not found.' });
      const balance = round2(Number(order.total) - Number(order.amount_paid));
      if (value > balance + 0.001) return res.status(400).json({ error: 'That is more than the balance due.' });

      const { error } = await supabase.from('payments').insert({
        user_id: user.id,
        order_id: order.id,
        amount: value,
        method: METHODS.includes(method) ? method : 'cash',
        note: String(note || '').trim().slice(0, 200) || null,
      });
      if (error) throw error;
      const updated = await recalc(user.id, order.id);
      return res.status(201).json(updated);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Payment id is required.' });
      const { data: pay, error: pErr } = await supabase
        .from('payments').select('id, order_id').eq('id', id).eq('user_id', user.id).maybeSingle();
      if (pErr) throw pErr;
      if (!pay) return res.status(404).json({ error: 'Payment not found.' });
      const { error } = await supabase.from('payments').delete().eq('id', id).eq('user_id', user.id);
      if (error) throw error;
      const updated = await recalc(user.id, pay.order_id);
      return res.status(200).json(updated);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

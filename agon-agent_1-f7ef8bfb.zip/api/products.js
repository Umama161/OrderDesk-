import supabase from './db-client.js';
import { cors, requireUser } from './_auth.js';

// Phase 1: read-only catalog (used by Quick Add for price matching + tap-to-add chips).
export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const user = await requireUser(req, res);
    if (!user) return;
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('user_id', user.id)
        .eq('active', true)
        .order('name', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

import supabase from './db-client.js';
import { cors, requireUser, getUsage, getSeller } from './_auth.js';

export const CURRENCIES = ['PKR', 'INR', 'BDT', 'AED', 'SAR', 'QAR', 'KWD', 'EGP', 'NGN', 'KES', 'MYR', 'IDR', 'TRY', 'GBP', 'EUR', 'USD'];
const LOCALES = ['en', 'ur', 'ar'];

function clean(body = {}) {
  const out = {};
  if (typeof body.shop_name === 'string') out.shop_name = body.shop_name.trim().slice(0, 80);
  if (typeof body.phone === 'string') out.phone = body.phone.replace(/[^\d+\s-]/g, '').trim().slice(0, 24) || null;
  if (CURRENCIES.includes(body.currency)) out.currency = body.currency;
  if (LOCALES.includes(body.locale)) out.locale = body.locale;
  return out;
}

export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const user = await requireUser(req, res);
    if (!user) return;

    if (req.method === 'GET') {
      const seller = await getSeller(user.id);
      if (!seller) return res.status(200).json({ seller: null, usage: null });
      const usage = await getUsage(user.id, seller.plan);
      return res.status(200).json({ seller, usage });
    }

    if (req.method === 'POST') {
      const fields = clean(req.body);
      if (!fields.shop_name) return res.status(400).json({ error: 'Add your shop name.' });
      const existing = await getSeller(user.id);
      if (existing) return res.status(200).json({ seller: existing });
      const { data, error } = await supabase
        .from('sellers')
        .insert({
          user_id: user.id,
          email: user.email || null,
          currency: 'USD',
          locale: 'en',
          plan: 'free',
          ...fields,
        })
        .select('*')
        .single();
      if (error) throw error;
      return res.status(201).json({ seller: data });
    }

    if (req.method === 'PUT') {
      const fields = clean(req.body);
      if ('shop_name' in fields && !fields.shop_name) return res.status(400).json({ error: 'Shop name can’t be empty.' });
      if (!Object.keys(fields).length) return res.status(400).json({ error: 'Nothing to update.' });
      const { data, error } = await supabase
        .from('sellers')
        .update(fields)
        .eq('user_id', user.id)
        .select('*')
        .single();
      if (error) throw error;
      return res.status(200).json({ seller: data });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

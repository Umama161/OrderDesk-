import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Sun, Users } from 'lucide-react';
import { AuthProvider } from './contexts/AuthContext';
import { SellerProvider, useSeller } from './contexts/SellerContext';
import { ProtectedRoute, RequireSeller } from './components/Guards';
import AppShell from './components/AppShell';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import Orders from './pages/Orders';
import QuickAdd from './pages/QuickAdd';
import OrderDetail from './pages/OrderDetail';
import Upgrade from './pages/Upgrade';
import More from './pages/More';
import Catalog from './pages/Catalog';
import ComingSoon from './pages/ComingSoon';

function TodayPage() {
  const { t } = useSeller();
  return <ComingSoon title={t('navToday')} icon={Sun} points={['Today’s orders', 'Revenue collected today', 'Total still unpaid']} />;
}

function CustomersPage() {
  const { t } = useSeller();
  return (
    <ComingSoon
      title={t('navCustomers')}
      icon={Users}
      points={['Customers are already saved automatically from every order', 'Order history and total spent per customer', 'One-tap re-order']}
    />
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SellerProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/onboarding" element={<ProtectedRoute><Onboarding /></ProtectedRoute>} />
            <Route element={<ProtectedRoute><RequireSeller><AppShell /></RequireSeller></ProtectedRoute>}>
              <Route index element={<Orders />} />
              <Route path="add" element={<QuickAdd />} />
              <Route path="orders/:id" element={<OrderDetail />} />
              <Route path="today" element={<TodayPage />} />
              <Route path="customers" element={<CustomersPage />} />
              <Route path="catalog" element={<Catalog />} />
              <Route path="more" element={<More />} />
              <Route path="upgrade" element={<Upgrade />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </SellerProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

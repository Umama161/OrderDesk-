import { NavLink, Outlet, useLocation, Link } from 'react-router-dom';
import { ClipboardList, Sun, Plus, Users, Menu } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';

export default function AppShell() {
  const loc = useLocation();
  const hideNav = loc.pathname.startsWith('/add');
  return (
    <div className="min-h-dvh paper-bg">
      <div className="mx-auto max-w-xl min-h-dvh bg-paper/70 sm:border-x sm:border-line/70">
        <main className={hideNav ? 'pb-10' : 'pb-32'}>
          <Outlet />
        </main>
      </div>
      {!hideNav && <BottomNav />}
    </div>
  );
}

function BottomNav() {
  const { t } = useSeller();
  const item = (to: string, label: string, Icon: typeof Sun, end = false) => (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `flex flex-col items-center justify-center gap-1 h-16 text-[12px] font-semibold transition ${isActive ? 'text-brand' : 'text-muted hover:text-ink'}`
      }
    >
      {({ isActive }) => (
        <>
          <span className={`grid place-items-center h-8 w-12 rounded-full transition ${isActive ? 'bg-brand-soft' : ''}`}>
            <Icon className="h-[22px] w-[22px]" strokeWidth={isActive ? 2.4 : 2} />
          </span>
          {label}
        </>
      )}
    </NavLink>
  );
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-xl bg-card/95 backdrop-blur-md border-t border-line grid grid-cols-5 items-end px-1">
        {item('/', t('navOrders'), ClipboardList, true)}
        {item('/today', t('navToday'), Sun)}
        <div className="flex justify-center">
          <Link
            to="/add"
            aria-label={t('quickAdd')}
            className="-mt-7 mb-2 h-16 w-16 rounded-[22px] bg-brand text-white grid place-items-center shadow-[0_12px_24px_-8px_rgb(31_92_74/0.7)] ring-4 ring-paper active:scale-95 transition hover:bg-brand-2"
          >
            <Plus className="h-8 w-8" strokeWidth={2.6} />
          </Link>
        </div>
        {item('/customers', t('navCustomers'), Users)}
        {item('/more', t('navMore'), Menu)}
      </div>
    </nav>
  );
}

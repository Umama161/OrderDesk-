import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSeller } from '../contexts/SellerContext';
import { FullScreenLoader, ErrorBox } from './ui';

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export function RequireSeller({ children }: { children: ReactNode }) {
  const { seller, loading, error, refresh } = useSeller();
  if (loading) return <FullScreenLoader />;
  if (error && !seller) {
    return (
      <div className="min-h-dvh grid place-items-center p-6 paper-bg">
        <div className="max-w-sm w-full"><ErrorBox message={error} onRetry={refresh} /></div>
      </div>
    );
  }
  if (!seller) return <Navigate to="/onboarding" replace />;
  return <>{children}</>;
}

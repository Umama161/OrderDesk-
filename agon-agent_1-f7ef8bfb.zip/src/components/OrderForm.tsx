import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Minus, Plus, Trash2, CalendarDays, MapPin, User, Phone, StickyNote, Wallet, ShoppingBag, Check } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, ApiError, errMsg } from '../lib/api';
import { addDays, dateLabel, localISO, money } from '../lib/format';
import type { Order, ParsedOrder, PayMethod, Product } from '../lib/types';
import { Card, Chip, SectionLabel, Spinner, inputCls, primaryBtn } from './ui';

type DraftItem = { key: string; product_id: number | null; name: string; quantity: number; unit_price: string };

let seq = 0;
const newKey = () => `i${++seq}`;
const blankItem = (): DraftItem => ({ key: newKey(), product_id: null, name: '', quantity: 1, unit_price: '' });

const METHODS: PayMethod[] = ['cash', 'bank', 'wallet', 'card', 'other'];

interface Props {
  initial: ParsedOrder;
  products: Product[];
  rawMessage: string;
}

export default function OrderForm({ initial, products, rawMessage }: Props) {
  const { t, seller, locale, refresh } = useSeller();
  const navigate = useNavigate();
  const currency = seller?.currency ?? 'USD';
  const fm = (n: number) => money(n, currency, locale);

  const [name, setName] = useState(initial.customer_name);
  const [phone, setPhone] = useState(initial.phone);
  const [items, setItems] = useState<DraftItem[]>(() =>
    initial.items.length
      ? initial.items.map((i) => ({
          key: newKey(),
          product_id: i.product_id,
          name: i.name,
          quantity: i.quantity || 1,
          unit_price: i.unit_price === null ? '' : String(i.unit_price),
        }))
      : [blankItem()],
  );
  const [date, setDate] = useState(initial.delivery_date);
  const [address, setAddress] = useState(initial.delivery_address);
  const [notes, setNotes] = useState(initial.notes);
  const [paid, setPaid] = useState(initial.amount_paid ? String(initial.amount_paid) : '');
  const [method, setMethod] = useState<PayMethod>('cash');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [limitHit, setLimitHit] = useState(false);

  const today = localISO();
  const tomorrow = addDays(today, 1);
  const total = useMemo(
    () => Math.round(items.reduce((s, i) => s + (Number(i.quantity) || 0) * (Number(i.unit_price) || 0), 0) * 100) / 100,
    [items],
  );
  const paidNum = Number(paid) || 0;
  const balance = Math.max(0, total - paidNum);

  const updateItem = (key: string, patch: Partial<DraftItem>) =>
    setItems((list) => list.map((i) => (i.key === key ? { ...i, ...patch } : i)));
  const removeItem = (key: string) =>
    setItems((list) => (list.length === 1 ? [blankItem()] : list.filter((i) => i.key !== key)));

  const addProduct = (p: Product) =>
    setItems((list) => {
      const existing = list.find((i) => i.product_id === p.id);
      if (existing) return list.map((i) => (i === existing ? { ...i, quantity: i.quantity + 1 } : i));
      const item: DraftItem = { key: newKey(), product_id: p.id, name: p.name, quantity: 1, unit_price: String(Number(p.price)) };
      const blankIdx = list.findIndex((i) => !i.name.trim());
      if (blankIdx >= 0) {
        const copy = [...list];
        copy[blankIdx] = item;
        return copy;
      }
      return [...list, item];
    });

  const onItemName = (key: string, value: string) => {
    const match = products.find((p) => p.name.toLowerCase() === value.trim().toLowerCase());
    setItems((list) =>
      list.map((i) =>
        i.key === key
          ? { ...i, name: value, product_id: match ? match.id : null, unit_price: match && i.unit_price === '' ? String(Number(match.price)) : i.unit_price }
          : i,
      ),
    );
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = t('errName');
    const filled = items.filter((i) => i.name.trim());
    if (!filled.length) e.items = t('errItems');
    for (const i of filled) {
      if (!(i.quantity > 0)) e[`qty-${i.key}`] = t('errQty');
      if (i.unit_price.trim() === '' || !(Number(i.unit_price) >= 0)) e[`price-${i.key}`] = t('errPrice');
    }
    if (paid !== '' && (!(paidNum >= 0) || paidNum > total)) e.paid = t('errPaid');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    setSaveError('');
    if (!validate()) {
      setTimeout(() => document.querySelector('[data-error="true"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 30);
      return;
    }
    setSaving(true);
    try {
      const order = await api<Order>('/api/orders', {
        method: 'POST',
        body: {
          customer: { name: name.trim(), phone: phone.trim() },
          items: items
            .filter((i) => i.name.trim())
            .map((i) => ({ product_id: i.product_id, name: i.name.trim(), quantity: i.quantity, unit_price: Number(i.unit_price) })),
          delivery_date: date,
          delivery_address: address.trim(),
          notes: notes.trim(),
          raw_message: rawMessage,
          amount_paid: paidNum,
          payment_method: method,
        },
      });
      await refresh();
      navigate(`/orders/${order.id}?new=1`, { replace: true });
    } catch (e) {
      if (e instanceof ApiError && e.code === 'LIMIT_REACHED') setLimitHit(true);
      setSaveError(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  const customDate = date && date !== today && date !== tomorrow;

  return (
    <div className="space-y-4">
      {/* Customer */}
      <Card className="p-4">
        <SectionLabel icon={<User className="h-4 w-4" />}>{t('customer')}</SectionLabel>
        <div className="space-y-3">
          <div data-error={!!errors.name}>
            <input
              className={`${inputCls} ${errors.name ? 'border-danger ring-4 ring-danger/10' : ''}`}
              placeholder={t('customerName')}
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="off"
            />
            {errors.name && <p className="mt-1.5 text-sm font-medium text-danger">{errors.name}</p>}
          </div>
          <div className="relative">
            <Phone className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
            <input
              className={`${inputCls} ps-12`}
              placeholder={t('phone')}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              inputMode="tel"
              dir="ltr"
              style={{ textAlign: 'start' }}
            />
          </div>
        </div>
      </Card>

      {/* Items */}
      <Card className="p-4">
        <SectionLabel icon={<ShoppingBag className="h-4 w-4" />}>{t('items')}</SectionLabel>
        {products.length > 0 && (
          <div className="-mx-4 px-4 mb-3 overflow-x-auto no-scrollbar">
            <div className="flex gap-2 w-max">
              {products.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => addProduct(p)}
                  className="h-11 ps-3 pe-4 rounded-full bg-accent-soft border border-accent/30 text-[14px] font-semibold text-ink inline-flex items-center gap-1.5 active:scale-95 transition whitespace-nowrap"
                >
                  <Plus className="h-4 w-4 text-[#9A5B05]" /> {p.name}
                  <span className="text-muted font-medium">· {fm(Number(p.price))}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="space-y-3" data-error={!!errors.items}>
          {items.map((i) => {
            const lineTotal = (Number(i.quantity) || 0) * (Number(i.unit_price) || 0);
            const qErr = errors[`qty-${i.key}`];
            const pErr = errors[`price-${i.key}`];
            return (
              <div key={i.key} className="rounded-2xl bg-paper/70 border border-line p-3" data-error={!!(qErr || pErr)}>
                <div className="flex gap-2">
                  <input
                    className={`${inputCls} h-12 flex-1`}
                    placeholder={t('itemName')}
                    value={i.name}
                    list="od-products"
                    onChange={(e) => onItemName(i.key, e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => removeItem(i.key)}
                    className="h-12 w-12 shrink-0 grid place-items-center rounded-2xl text-muted hover:text-danger hover:bg-danger-soft transition"
                    aria-label={t('remove')}
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <div className={`flex items-center rounded-2xl border bg-card ${qErr ? 'border-danger' : 'border-line'}`}>
                    <button type="button" className="h-12 w-11 grid place-items-center active:scale-90 transition" onClick={() => updateItem(i.key, { quantity: Math.max(1, i.quantity - 1) })} aria-label="-1">
                      <Minus className="h-5 w-5" />
                    </button>
                    <input
                      className="w-10 text-center text-[17px] font-bold bg-transparent outline-none"
                      inputMode="decimal"
                      value={i.quantity}
                      onChange={(e) => updateItem(i.key, { quantity: Number(e.target.value.replace(/[^\d.]/g, '')) || 0 })}
                    />
                    <button type="button" className="h-12 w-11 grid place-items-center active:scale-90 transition" onClick={() => updateItem(i.key, { quantity: i.quantity + 1 })} aria-label="+1">
                      <Plus className="h-5 w-5" />
                    </button>
                  </div>
                  <span className="text-muted">×</span>
                  <div className="relative flex-1 min-w-0">
                    <span className="absolute start-3 top-1/2 -translate-y-1/2 text-[13px] font-bold text-muted">{currency}</span>
                    <input
                      className={`${inputCls} h-12 ps-13 ${pErr ? 'border-danger ring-4 ring-danger/10' : ''}`}
                      placeholder={t('price')}
                      inputMode="decimal"
                      value={i.unit_price}
                      onChange={(e) => updateItem(i.key, { unit_price: e.target.value.replace(/[^\d.]/g, '') })}
                    />
                  </div>
                </div>
                <div className="mt-2 flex items-center justify-between text-sm">
                  <span className="text-danger font-medium">{qErr || pErr || ''}</span>
                  <span className="font-semibold text-ink-2">{fm(lineTotal)}</span>
                </div>
              </div>
            );
          })}
          <datalist id="od-products">
            {products.map((p) => <option key={p.id} value={p.name} />)}
          </datalist>
          {errors.items && <p className="text-sm font-medium text-danger">{errors.items}</p>}
          <button
            type="button"
            onClick={() => setItems((l) => [...l, blankItem()])}
            className="w-full h-12 rounded-2xl border-2 border-dashed border-line text-ink-2 font-semibold inline-flex items-center justify-center gap-2 hover:border-brand hover:text-brand transition"
          >
            <Plus className="h-5 w-5" /> {t('addItem')}
          </button>
        </div>
      </Card>

      {/* Delivery */}
      <Card className="p-4">
        <SectionLabel icon={<CalendarDays className="h-4 w-4" />}>{t('delivery')}</SectionLabel>
        <div className="flex flex-wrap gap-2">
          <Chip active={date === today} onClick={() => setDate(today)}>{t('today')}</Chip>
          <Chip active={date === tomorrow} onClick={() => setDate(tomorrow)}>{t('tomorrow')}</Chip>
          <label
            className={`relative h-11 px-4 rounded-full border text-[15px] font-semibold inline-flex items-center gap-1.5 cursor-pointer transition ${
              customDate ? 'bg-ink text-paper border-ink' : 'bg-card text-ink-2 border-line'
            }`}
          >
            <CalendarDays className="h-4 w-4" />
            {customDate ? dateLabel(date, locale).label : t('pickDate')}
            <input
              type="date"
              value={date}
              min={today}
              onChange={(e) => setDate(e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer"
              onClick={(e) => (e.currentTarget as HTMLInputElement & { showPicker?: () => void }).showPicker?.()}
            />
          </label>
          <Chip active={!date} onClick={() => setDate('')}>{t('noDate')}</Chip>
        </div>
        <div className="relative mt-3">
          <MapPin className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
          <input className={`${inputCls} ps-12`} placeholder={t('address')} value={address} onChange={(e) => setAddress(e.target.value)} />
        </div>
        <div className="relative mt-3">
          <StickyNote className="absolute start-4 top-4 h-5 w-5 text-muted" />
          <textarea
            className={`${inputCls} h-auto min-h-[56px] py-3.5 ps-12 resize-none`}
            rows={2}
            placeholder={t('notesPlaceholder')}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
      </Card>

      {/* Payment */}
      <Card className="p-4">
        <SectionLabel icon={<Wallet className="h-4 w-4" />}>{t('amountPaid')}</SectionLabel>
        <div className="flex flex-wrap gap-2">
          <Chip active={paidNum === 0} onClick={() => setPaid('')}>{t('nothing')}</Chip>
          <Chip active={total > 0 && paidNum === Math.round(total / 2)} onClick={() => setPaid(String(Math.round(total / 2)))}>{t('half')}</Chip>
          <Chip active={total > 0 && paidNum === total} onClick={() => setPaid(String(total))}>{t('full')}</Chip>
        </div>
        <div className="relative mt-3" data-error={!!errors.paid}>
          <span className="absolute start-4 top-1/2 -translate-y-1/2 text-[13px] font-bold text-muted">{currency}</span>
          <input
            className={`${inputCls} ps-15 ${errors.paid ? 'border-danger ring-4 ring-danger/10' : ''}`}
            placeholder="0"
            inputMode="decimal"
            value={paid}
            onChange={(e) => setPaid(e.target.value.replace(/[^\d.]/g, ''))}
          />
        </div>
        {errors.paid && <p className="mt-1.5 text-sm font-medium text-danger">{errors.paid}</p>}
        {paidNum > 0 && (
          <div className="mt-3">
            <div className="text-sm text-muted mb-2">{t('method')}</div>
            <div className="flex flex-wrap gap-2">
              {METHODS.map((m) => (
                <Chip key={m} active={method === m} onClick={() => setMethod(m)}>{t(m)}</Chip>
              ))}
            </div>
          </div>
        )}
      </Card>

      {rawMessage && (
        <details className="rounded-2xl border border-line bg-card/60 px-4 py-3 text-sm">
          <summary className="cursor-pointer font-semibold text-ink-2">{t('originalMessage')}</summary>
          <p className="mt-2 whitespace-pre-wrap text-muted">{rawMessage}</p>
        </details>
      )}

      {saveError && (
        <div className="rounded-2xl border border-danger/30 bg-danger-soft px-4 py-3 text-danger text-[15px]">
          {saveError}
          {limitHit && (
            <Link to="/upgrade" className="block mt-2 font-bold underline underline-offset-4">{t('upgrade')} →</Link>
          )}
        </div>
      )}

      <div className="h-36" />

      {/* Sticky total + save */}
      <div className="fixed bottom-0 inset-x-0 z-30 pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto max-w-xl px-3 pb-3">
          <div className="rounded-3xl bg-ink text-paper p-3 shadow-2xl">
            <div className="flex items-center justify-between px-2 pb-3 text-sm">
              <div>
                <div className="text-paper/60">{t('total')}</div>
                <div className="font-display text-2xl font-bold">{fm(total)}</div>
              </div>
              <div className="text-end">
                <div className="text-paper/60">{t('paid')} · {t('balance')}</div>
                <div className="font-semibold text-[15px]">
                  {fm(paidNum)} · <span className={balance > 0 ? 'text-accent' : 'text-[#7FD3B0]'}>{fm(balance)}</span>
                </div>
              </div>
            </div>
            <button type="button" onClick={save} disabled={saving} className={`${primaryBtn} w-full bg-accent text-ink hover:bg-[#F5B957] shadow-none`}>
              {saving ? <Spinner /> : <Check className="h-5 w-5" strokeWidth={3} />}
              {saving ? t('saving') : t('saveOrder')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

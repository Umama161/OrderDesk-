import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { money } from '../lib/format';
import type { PayMethod } from '../lib/types';
import { Chip, Spinner, inputCls, primaryBtn } from './ui';

const METHODS: PayMethod[] = ['cash', 'bank', 'wallet', 'card', 'other'];

export default function PaymentSheet({ open, onClose, orderId, balance, currency, onSaved }: {
  open: boolean;
  onClose: () => void;
  orderId: number;
  balance: number;
  currency: string;
  onSaved: () => void;
}) {
  const { t, locale } = useSeller();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PayMethod>('cash');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    const value = Number(amount);
    if (!(value > 0)) return setError(t('amount') + ' > 0');
    if (value > balance + 0.001) return setError(`${t('balance')}: ${money(balance, currency, locale)}`);
    setSaving(true);
    setError('');
    try {
      await api('/api/payments', { method: 'POST', body: { order_id: orderId, amount: value, method, note } });
      setAmount('');
      setNote('');
      onSaved();
      onClose();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-end justify-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-ink/40 backdrop-blur-[2px]" onClick={onClose} />
          <motion.div
            className="relative w-full max-w-xl rounded-t-[28px] bg-paper p-5 pb-[max(env(safe-area-inset-bottom),20px)] shadow-2xl"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 320 }}
          >
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-line" />
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-2xl font-bold">{t('recordPayment')}</h2>
              <button type="button" onClick={onClose} className="h-11 w-11 grid place-items-center rounded-full hover:bg-paper-2" aria-label="Close">
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="relative">
              <span className="absolute start-4 top-1/2 -translate-y-1/2 text-[13px] font-bold text-muted">{currency}</span>
              <input
                autoFocus
                className={`${inputCls} h-16 ps-16 text-2xl font-display font-bold`}
                inputMode="decimal"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ''))}
              />
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              <Chip active={Number(amount) === balance} onClick={() => setAmount(String(balance))}>
                {t('fillBalance')} · {money(balance, currency, locale)}
              </Chip>
            </div>
            <div className="text-sm text-muted mt-4 mb-2">{t('method')}</div>
            <div className="flex flex-wrap gap-2">
              {METHODS.map((m) => (
                <Chip key={m} active={method === m} onClick={() => setMethod(m)}>{t(m)}</Chip>
              ))}
            </div>
            <input className={`${inputCls} mt-4`} placeholder={t('notes')} value={note} onChange={(e) => setNote(e.target.value)} />
            {error && <p className="mt-3 text-danger font-medium">{error}</p>}
            <button type="button" onClick={submit} disabled={saving} className={`${primaryBtn} w-full mt-5`}>
              {saving && <Spinner />} {t('savePayment')}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

import { Link } from 'react-router-dom';
import { Infinity as InfinityIcon, ArrowRight } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';

export default function UsageMeter() {
  const { usage, t } = useSeller();
  if (!usage) return null;
  if (usage.limit === null) {
    return (
      <div className="rounded-2xl bg-brand text-white px-4 py-3 flex items-center gap-3">
        <InfinityIcon className="h-5 w-5" />
        <span className="font-semibold">{t('unlimitedPlan')}</span>
        <span className="ms-auto text-white/80 text-sm">{usage.used} {t('ordersThisMonth')}</span>
      </div>
    );
  }
  const pct = Math.min(100, (usage.used / usage.limit) * 100);
  const bar = pct >= 100 ? 'bg-danger' : pct >= 80 ? 'bg-accent' : 'bg-brand';
  return (
    <Link to="/upgrade" className="block rounded-2xl bg-card border border-line px-4 py-3.5 active:scale-[0.99] transition hover:border-ink/20">
      <div className="flex items-baseline gap-1.5">
        <span className="font-display text-2xl font-bold">{usage.used}</span>
        <span className="text-muted">/ {usage.limit} {t('ordersThisMonth')}</span>
        <span className="ms-auto inline-flex items-center gap-1 text-sm font-bold text-brand">
          {t('upgrade')} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
        </span>
      </div>
      <div className="h-2 mt-2.5 rounded-full bg-paper-2 overflow-hidden">
        <div className={`h-full rounded-full ${bar} transition-all duration-700`} style={{ width: `${pct}%` }} />
      </div>
    </Link>
  );
}

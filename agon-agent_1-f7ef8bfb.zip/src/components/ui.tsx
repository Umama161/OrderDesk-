import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Loader2 } from 'lucide-react';
import type { OrderStatus } from '../lib/types';
import type { PayState } from '../lib/format';
import { useSeller } from '../contexts/SellerContext';

export const inputCls =
  'w-full h-13 rounded-2xl border border-line bg-card px-4 text-[17px] text-ink placeholder:text-muted/70 outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10';

export const primaryBtn =
  'inline-flex items-center justify-center gap-2 h-14 px-6 rounded-2xl bg-brand text-white text-[17px] font-semibold shadow-[0_8px_20px_-8px_rgb(31_92_74/0.6)] transition active:scale-[0.98] hover:bg-brand-2 disabled:opacity-60 disabled:active:scale-100';

export const secondaryBtn =
  'inline-flex items-center justify-center gap-2 h-14 px-5 rounded-2xl bg-card border border-line text-ink text-[16px] font-semibold transition active:scale-[0.98] hover:border-ink/30 disabled:opacity-60';

export function Logo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden>
      <rect width="64" height="64" rx="18" fill="#1F5C4A" />
      <path d="M17 16h30a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H31l-10 8v-8h-4a4 4 0 0 1-4-4V20a4 4 0 0 1 4-4z" fill="#FBF6EC" />
      <path d="M24 30.5l5.5 5.5L41 24.5" stroke="#1F5C4A" strokeWidth="4.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="51" cy="14" r="7" fill="#F0A93B" />
    </svg>
  );
}

export function Spinner({ className = 'h-5 w-5' }: { className?: string }) {
  return <Loader2 className={`animate-spin ${className}`} />;
}

export function FullScreenLoader({ label }: { label?: string }) {
  return (
    <div className="min-h-dvh grid place-items-center paper-bg">
      <div className="flex flex-col items-center gap-4 text-muted">
        <div className="animate-pulse"><Logo size={56} /></div>
        <div className="flex items-center gap-2 text-sm"><Spinner className="h-4 w-4" />{label ?? 'Loading…'}</div>
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle, back, right }: { title: ReactNode; subtitle?: ReactNode; back?: string | boolean; right?: ReactNode }) {
  const navigate = useNavigate();
  const { t } = useSeller();
  return (
    <header className="sticky top-0 z-20 bg-paper/90 backdrop-blur-md border-b border-line/70 px-4 pt-[max(env(safe-area-inset-top),14px)] pb-3 flex items-center gap-2">
      {back && (
        <button
          type="button"
          onClick={() => (typeof back === 'string' ? navigate(back) : navigate(-1))}
          className="h-12 w-12 -ms-3 grid place-items-center rounded-full hover:bg-paper-2 active:scale-95 transition"
          aria-label={t('back')}
        >
          <ChevronLeft className="h-6 w-6 rtl:rotate-180" />
        </button>
      )}
      <div className="flex-1 min-w-0">
        <h1 className="font-display text-[26px] leading-tight font-bold tracking-tight truncate">{title}</h1>
        {subtitle && <div className="text-sm text-muted truncate">{subtitle}</div>}
      </div>
      {right}
    </header>
  );
}

export function Chip({ active, onClick, children, className = '' }: { active?: boolean; onClick?: () => void; children: ReactNode; className?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-11 px-4 rounded-full border text-[15px] font-semibold whitespace-nowrap transition active:scale-95 inline-flex items-center gap-1.5 ${
        active ? 'bg-ink text-paper border-ink' : 'bg-card text-ink-2 border-line hover:border-ink/30'
      } ${className}`}
    >
      {children}
    </button>
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-3xl bg-card border border-line shadow-card ${className}`}>{children}</section>;
}

export function SectionLabel({ children, icon }: { children: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.08em] text-muted mb-3">
      {icon}
      {children}
    </div>
  );
}

export function PayBadge({ state }: { state: PayState }) {
  const { t } = useSeller();
  const map = {
    paid: ['bg-brand-soft text-brand', t('payPaid')],
    partial: ['bg-accent-soft text-[#9A5B05]', t('payPartial')],
    unpaid: ['bg-danger-soft text-danger', t('payUnpaid')],
  } as const;
  const [cls, label] = map[state];
  return <span className={`inline-flex items-center h-7 px-2.5 rounded-full text-[13px] font-bold ${cls}`}>{label}</span>;
}

export function StatusBadge({ status }: { status: OrderStatus }) {
  const { t } = useSeller();
  const map: Record<OrderStatus, [string, string]> = {
    new: ['bg-[#E7ECFB] text-[#2C4BA8]', t('statusNew')],
    confirmed: ['bg-brand-soft text-brand', t('statusConfirmed')],
    delivered: ['bg-paper-2 text-ink-2', t('statusDelivered')],
    cancelled: ['bg-paper-2 text-muted line-through', t('statusCancelled')],
  };
  const [cls, label] = map[status];
  return <span className={`inline-flex items-center h-7 px-2.5 rounded-full text-[13px] font-bold ${cls}`}>{label}</span>;
}

const AVATAR_COLORS = ['#F0A93B', '#1F5C4A', '#C9472F', '#2C4BA8', '#8B5CF6', '#0E7490', '#B45309', '#BE185D'];

export function Avatar({ name, size = 44 }: { name: string; size?: number }) {
  const clean = (name || '?').trim();
  let h = 0;
  for (const ch of clean) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const color = AVATAR_COLORS[h % AVATAR_COLORS.length];
  const initials = clean.split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  return (
    <div
      className="shrink-0 grid place-items-center rounded-2xl font-display font-bold text-white"
      style={{ width: size, height: size, background: color, fontSize: size * 0.38 }}
    >
      {initials || '?'}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  const { t } = useSeller();
  return (
    <div className="rounded-2xl border border-danger/30 bg-danger-soft px-4 py-3 text-danger text-[15px] flex items-center gap-3">
      <span className="flex-1">{message}</span>
      {onRetry && (
        <button type="button" onClick={onRetry} className="h-10 px-3 rounded-xl bg-card font-semibold text-ink border border-line">
          {t('retry')}
        </button>
      )}
    </div>
  );
}

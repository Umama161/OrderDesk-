import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { api, errMsg } from '../lib/api';
import { translate, type I18nKey } from '../lib/i18n';
import { isRTL } from '../lib/format';
import type { Locale, Seller, Usage } from '../lib/types';

interface SellerCtx {
  seller: Seller | null;
  usage: Usage | null;
  loading: boolean;
  error: string;
  refresh: () => Promise<void>;
  locale: Locale;
  setPreviewLocale: (l: Locale) => void;
  t: (k: I18nKey) => string;
}

const Ctx = createContext<SellerCtx | null>(null);

const storedLocale = (): Locale => {
  const v = typeof localStorage !== 'undefined' ? localStorage.getItem('od_locale') : null;
  return v === 'ur' || v === 'ar' ? v : 'en';
};

export function SellerProvider({ children }: { children: ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const [seller, setSeller] = useState<Seller | null>(null);
  const [usage, setUsage] = useState<Usage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState<Locale>(storedLocale);
  const userId = user?.id;

  const refresh = useCallback(async () => {
    if (!userId) {
      setSeller(null);
      setUsage(null);
      setLoading(false);
      return;
    }
    try {
      setError('');
      const r = await api<{ seller: Seller | null; usage: Usage | null }>('/api/seller');
      setSeller(r.seller);
      setUsage(r.usage);
      if (r.seller) {
        localStorage.setItem('od_locale', r.seller.locale);
        setPreview(r.seller.locale);
      }
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (authLoading) return;
    setLoading(true);
    refresh();
  }, [authLoading, refresh]);

  const locale: Locale = seller?.locale ?? preview;

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = isRTL(locale) ? 'rtl' : 'ltr';
  }, [locale]);

  const setPreviewLocale = (l: Locale) => {
    localStorage.setItem('od_locale', l);
    setPreview(l);
  };

  const t = useCallback((k: I18nKey) => translate(locale, k), [locale]);

  return (
    <Ctx.Provider value={{ seller, usage, loading: loading || authLoading, error, refresh, locale, setPreviewLocale, t }}>
      {children}
    </Ctx.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useSeller() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useSeller must be used inside SellerProvider');
  return c;
}

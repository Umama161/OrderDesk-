import type { Locale, Order, Seller } from './types';
import { balanceOf, dateLabel, money } from './format';

const COUNTRY_CODES: Record<string, string> = {
  PKR: '92', INR: '91', BDT: '880', AED: '971', SAR: '966', QAR: '974', KWD: '965', EGP: '20',
  NGN: '234', KES: '254', MYR: '60', IDR: '62', TRY: '90', GBP: '44',
};

const T: Record<Locale, Record<string, string>> = {
  en: {
    hi: 'Hi {name}! 👋',
    thanks: 'Thank you for your order with {shop}. Here are the details:',
    order: 'Order',
    total: 'Total',
    paid: 'Paid',
    balance: 'Balance due',
    fully: 'Fully paid — thank you!',
    delivery: 'Delivery',
    address: 'Address',
    notes: 'Notes',
    close: 'Please reply if anything needs changing. Thank you! 🙏',
  },
  ur: {
    hi: 'السلام علیکم {name}! 👋',
    thanks: '{shop} سے آرڈر کرنے کا شکریہ۔ تفصیل یہ ہے:',
    order: 'آرڈر',
    total: 'کل',
    paid: 'ادا شدہ',
    balance: 'بقایا',
    fully: 'پوری ادائیگی موصول — شکریہ!',
    delivery: 'ڈیلیوری',
    address: 'پتہ',
    notes: 'نوٹس',
    close: 'اگر کچھ تبدیل کرنا ہو تو بتا دیجیے۔ شکریہ! 🙏',
  },
  ar: {
    hi: 'مرحباً {name}! 👋',
    thanks: 'شكراً لطلبك من {shop}. إليك التفاصيل:',
    order: 'طلب',
    total: 'الإجمالي',
    paid: 'المدفوع',
    balance: 'المتبقي',
    fully: 'تم الدفع بالكامل — شكراً!',
    delivery: 'التوصيل',
    address: 'العنوان',
    notes: 'ملاحظات',
    close: 'أخبرنا إذا أردت أي تعديل. شكراً! 🙏',
  },
};

export function buildConfirmation(order: Order, seller: Seller) {
  const locale = seller.locale;
  const t = T[locale] ?? T.en;
  const cur = order.currency || seller.currency;
  const fm = (n: number) => money(n, cur, locale);
  const firstName = (order.customers?.name || '').split(' ')[0] || '';
  const lines: string[] = [];
  lines.push(t.hi.replace('{name}', firstName).replace(' !', '!'));
  lines.push(t.thanks.replace('{shop}', seller.shop_name));
  lines.push('');
  lines.push(`🧾 ${t.order} #${order.order_number}`);
  for (const i of order.order_items ?? []) {
    const lineTotal = i.line_total ?? Number(i.quantity) * Number(i.unit_price ?? 0);
    lines.push(`• ${Number(i.quantity)} × ${i.name} — ${fm(lineTotal)}`);
  }
  lines.push('');
  lines.push(`${t.total}: ${fm(order.total)}`);
  const bal = balanceOf(order);
  if (Number(order.amount_paid) > 0 && bal > 0) lines.push(`${t.paid}: ${fm(order.amount_paid)}`);
  if (bal > 0) lines.push(`${t.balance}: ${fm(bal)}`);
  else lines.push(`✅ ${t.fully}`);
  if (order.delivery_date || order.delivery_address) lines.push('');
  if (order.delivery_date) {
    const { label } = dateLabel(order.delivery_date, locale, { weekday: 'long', day: 'numeric', month: 'long' });
    lines.push(`📅 ${t.delivery}: ${label}`);
  }
  if (order.delivery_address) lines.push(`📍 ${t.address}: ${order.delivery_address}`);
  if (order.notes) lines.push(`📝 ${t.notes}: ${order.notes}`);
  lines.push('');
  lines.push(t.close);
  lines.push(`— ${seller.shop_name}`);
  return lines.join('\n');
}

/** wa.me needs an international number. Local numbers starting with 0 get the
 *  country code implied by the seller's currency. */
export function whatsappLink(phone: string | null | undefined, text: string, currency: string) {
  const encoded = encodeURIComponent(text);
  if (!phone) return `https://wa.me/?text=${encoded}`;
  let digits = phone.replace(/[^\d+]/g, '');
  if (digits.startsWith('+')) digits = digits.slice(1);
  else if (digits.startsWith('00')) digits = digits.slice(2);
  else if (digits.startsWith('0') && COUNTRY_CODES[currency]) digits = COUNTRY_CODES[currency] + digits.slice(1);
  return `https://wa.me/${digits}?text=${encoded}`;
}

import type { Locale, Order } from './types';

export const CURRENCIES: { code: string; label: string }[] = [
  { code: 'PKR', label: 'Pakistani Rupee' },
  { code: 'INR', label: 'Indian Rupee' },
  { code: 'BDT', label: 'Bangladeshi Taka' },
  { code: 'AED', label: 'UAE Dirham' },
  { code: 'SAR', label: 'Saudi Riyal' },
  { code: 'QAR', label: 'Qatari Riyal' },
  { code: 'KWD', label: 'Kuwaiti Dinar' },
  { code: 'EGP', label: 'Egyptian Pound' },
  { code: 'NGN', label: 'Nigerian Naira' },
  { code: 'KES', label: 'Kenyan Shilling' },
  { code: 'MYR', label: 'Malaysian Ringgit' },
  { code: 'IDR', label: 'Indonesian Rupiah' },
  { code: 'TRY', label: 'Turkish Lira' },
  { code: 'GBP', label: 'British Pound' },
  { code: 'EUR', label: 'Euro' },
  { code: 'USD', label: 'US Dollar' },
];

export const LANGUAGES: { code: Locale; label: string }[] = [
  { code: 'en', label: 'English' },
  { code: 'ur', label: 'اردو' },
  { code: 'ar', label: 'العربية' },
];

export const isRTL = (l: Locale) => l === 'ur' || l === 'ar';

export const intlLocale = (l: Locale) =>
  l === 'ur' ? 'ur-PK-u-nu-latn' : l === 'ar' ? 'ar-u-nu-latn' : 'en-GB';

export function money(amount: number, currency: string, locale: Locale) {
  const n = Number(amount) || 0;
  try {
    return new Intl.NumberFormat(intlLocale(locale), {
      style: 'currency',
      currency,
      currencyDisplay: 'narrowSymbol',
      minimumFractionDigits: 0,
      maximumFractionDigits: Number.isInteger(n) ? 0 : 2,
    }).format(n);
  } catch {
    return `${currency} ${n.toLocaleString()}`;
  }
}

export function localISO(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function addDays(iso: string, n: number) {
  const [y, m, d] = iso.split('-').map(Number);
  return localISO(new Date(y, m - 1, d + n));
}

/** Formats a YYYY-MM-DD date. Returns { rel: 'today'|'tomorrow'|'past'|null, label } */
export function dateLabel(iso: string, locale: Locale, opts: Intl.DateTimeFormatOptions = { weekday: 'short', day: 'numeric', month: 'short' }) {
  const [y, m, d] = iso.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  const today = localISO();
  const rel = iso === today ? 'today' : iso === addDays(today, 1) ? 'tomorrow' : iso < today ? 'past' : null;
  return { rel, label: new Intl.DateTimeFormat(intlLocale(locale), opts).format(date) };
}

export function timeAgo(isoTs: string, locale: Locale) {
  const diff = (Date.now() - new Date(isoTs).getTime()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(intlLocale(locale), { numeric: 'auto' });
  if (diff < 60) return rtf.format(0, 'second');
  if (diff < 3600) return rtf.format(-Math.floor(diff / 60), 'minute');
  if (diff < 86400) return rtf.format(-Math.floor(diff / 3600), 'hour');
  return rtf.format(-Math.floor(diff / 86400), 'day');
}

export type PayState = 'paid' | 'partial' | 'unpaid';
export function payState(o: Pick<Order, 'total' | 'amount_paid'>): PayState {
  const total = Number(o.total);
  const paid = Number(o.amount_paid);
  if (paid >= total && total > 0) return 'paid';
  if (total === 0) return 'paid';
  if (paid > 0) return 'partial';
  return 'unpaid';
}

export const balanceOf = (o: Pick<Order, 'total' | 'amount_paid'>) =>
  Math.max(0, Math.round((Number(o.total) - Number(o.amount_paid)) * 100) / 100);

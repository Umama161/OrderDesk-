export type Locale = 'en' | 'ur' | 'ar';
export type OrderStatus = 'new' | 'confirmed' | 'delivered' | 'cancelled';
export type PayMethod = 'cash' | 'bank' | 'card' | 'wallet' | 'other';

export interface Seller {
  user_id: string;
  shop_name: string;
  phone: string | null;
  email: string | null;
  currency: string;
  locale: Locale;
  plan: 'free' | 'pro';
  created_at: string;
}

export interface Usage {
  used: number;
  limit: number | null;
  plan: string;
  resets_at: string;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  unit: string | null;
  active: boolean;
}

export interface Customer {
  id: number;
  name: string;
  phone: string | null;
  address?: string | null;
}

export interface OrderItem {
  id: number;
  product_id: number | null;
  name: string;
  quantity: number;
  unit_price?: number;
  line_total?: number;
}

export interface Payment {
  id: number;
  order_id: number;
  amount: number;
  method: PayMethod;
  note: string | null;
  paid_at: string;
}

export interface Order {
  id: number;
  order_number: number;
  customer_id: number | null;
  status: OrderStatus;
  delivery_date: string | null;
  delivery_address: string | null;
  notes: string | null;
  raw_message: string | null;
  total: number;
  amount_paid: number;
  currency: string;
  created_at: string;
  customers?: Customer | null;
  order_items?: OrderItem[];
  payments?: Payment[];
}

export interface ParsedItem {
  product_id: number | null;
  name: string;
  quantity: number;
  unit_price: number | null;
}

export interface ParsedOrder {
  customer_name: string;
  phone: string;
  items: ParsedItem[];
  delivery_date: string;
  delivery_address: string;
  amount_paid: number;
  notes: string;
}

import { useEffect, useState } from 'react';
import { Package, Info } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { money } from '../lib/format';
import type { Product } from '../lib/types';
import { Card, ErrorBox, PageHeader } from '../components/ui';

export default function Catalog() {
  const { t, seller, locale } = useSeller();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchProducts = async () => {
    try {
      setError('');
      setProducts(await api<Product[]>('/api/products'));
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchProducts(); }, []);

  return (
    <div>
      <PageHeader title={t('catalog')} back="/more" />
      <div className="p-4 space-y-3">
        <div className="rounded-2xl border border-accent/50 bg-accent-soft px-4 py-3 text-[15px] flex gap-3">
          <Info className="h-5 w-5 shrink-0 mt-0.5 text-[#9A5B05]" />
          <span>Quick Add uses these products to fill in prices automatically. Adding and editing products is {t('comingSoon').toLowerCase()}.</span>
        </div>
        {error && <ErrorBox message={error} onRetry={fetchProducts} />}
        {loading && [1, 2, 3].map((i) => <div key={i} className="h-16 rounded-2xl bg-card border border-line animate-pulse" />)}
        {!loading && !error && products.length === 0 && (
          <p className="text-center text-muted py-8">No products yet. Items you type in orders are saved on the order for now.</p>
        )}
        {products.length > 0 && (
          <Card className="divide-y divide-line overflow-hidden">
            {products.map((p) => (
              <div key={p.id} className="flex items-center gap-3 px-4 h-16">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-paper-2 text-ink-2"><Package className="h-5 w-5" /></span>
                <span className="flex-1 font-semibold">{p.name}</span>
                <span className="font-display font-bold">{money(Number(p.price), seller?.currency ?? 'USD', locale)}</span>
              </div>
            ))}
          </Card>
        )}
      </div>
    </div>
  );
}

import type { LucideIcon } from 'lucide-react';
import { Clock3 } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { PageHeader } from '../components/ui';

export default function ComingSoon({ title, icon: Icon, points }: { title: string; icon: LucideIcon; points: string[] }) {
  const { t } = useSeller();
  return (
    <div>
      <PageHeader title={title} />
      <div className="p-4">
        <div className="rounded-[28px] border-2 border-dashed border-line bg-card/70 p-6 text-center">
          <div className="mx-auto h-16 w-16 rounded-[22px] bg-accent-soft text-[#9A5B05] grid place-items-center">
            <Icon className="h-8 w-8" />
          </div>
          <div className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-ink text-paper px-3 h-8 text-sm font-semibold">
            <Clock3 className="h-4 w-4" /> {t('comingSoon')}
          </div>
          <ul className="mt-5 space-y-2 text-start max-w-xs mx-auto">
            {points.map((p) => (
              <li key={p} className="flex gap-2 text-ink-2"><span className="text-accent">●</span> {p}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

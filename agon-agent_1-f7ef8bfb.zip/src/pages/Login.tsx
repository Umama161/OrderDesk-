import { useState, type FormEvent } from 'react';
import { Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, MessageCircleMore, Wallet, Send } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';
import { useSeller } from '../contexts/SellerContext';
import { LANGUAGES } from '../lib/format';
import { Logo, Spinner, inputCls, primaryBtn, secondaryBtn } from '../components/ui';

const DEMO = { email: 'demo@orderdesk.app', password: 'orderdesk123' };

export default function Login() {
  const { user, loading } = useAuth();
  const { t, locale, setPreviewLocale } = useSeller();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string; form?: string }>({});
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  if (!loading && user) return <Navigate to="/" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) errs.email = 'Enter a valid email address';
    if (password.length < 6) errs.password = 'Password must be at least 6 characters';
    setErrors(errs);
    setInfo('');
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      if (mode === 'signin') {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      } else {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password });
        if (error) throw error;
        if (!data.session) {
          setInfo(t('checkEmail'));
          setMode('signin');
        }
      }
    } catch (err) {
      setErrors({ form: err instanceof Error ? err.message : 'Sign in failed' });
    } finally {
      setBusy(false);
    }
  };

  const points = [
    { icon: MessageCircleMore, text: 'Paste a WhatsApp or Instagram chat — get a clean order' },
    { icon: Wallet, text: 'See who has paid and who still owes' },
    { icon: Send, text: 'Send a professional confirmation in one tap' },
  ];

  return (
    <div className="min-h-dvh paper-bg">
      <div className="mx-auto max-w-md px-5 pt-[max(env(safe-area-inset-top),20px)] pb-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Logo size={40} />
            <span className="font-display text-2xl font-extrabold tracking-tight">OrderDesk</span>
          </div>
          <div className="flex gap-1 rounded-full bg-card border border-line p-1">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                type="button"
                onClick={() => setPreviewLocale(l.code)}
                className={`h-9 px-3 rounded-full text-sm font-semibold transition ${locale === l.code ? 'bg-ink text-paper' : 'text-ink-2'}`}
              >
                {l.code === 'en' ? 'EN' : l.label}
              </button>
            ))}
          </div>
        </div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mt-8">
          <div className="relative rounded-[32px] overflow-hidden bg-brand text-white p-6 pb-7">
            <div className="absolute -end-10 -top-10 h-40 w-40 rounded-full bg-accent/90" />
            <div className="absolute end-6 top-6 rotate-6 rounded-2xl rounded-be-sm bg-[#DCF8C6] text-ink text-[13px] px-3 py-2 shadow-lg max-w-[60%] leading-snug">
              Ayesha wants 2 chocolate cakes, deliver Friday to F-7 🎂
            </div>
            <div className="relative pt-24">
              <h1 className="font-display text-[34px] leading-[1.05] font-extrabold tracking-tight">
                Chat orders in.<br />
                <span className="text-accent">Clean order list</span> out.
              </h1>
              <p className="mt-3 text-white/80 text-[16px]">Built for home bakers, boutiques and small sellers who sell in the DMs.</p>
            </div>
          </div>
          <ul className="mt-5 space-y-2.5">
            {points.map(({ icon: Icon, text }, i) => (
              <motion.li
                key={text}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="flex items-center gap-3 text-[15px] text-ink-2"
              >
                <span className="grid place-items-center h-9 w-9 rounded-xl bg-accent-soft text-[#9A5B05]"><Icon className="h-5 w-5" /></span>
                {text}
              </motion.li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.5 }}
          className="mt-7 rounded-[28px] bg-card border border-line shadow-card p-5"
        >
          <div className="grid grid-cols-2 gap-1 rounded-2xl bg-paper-2 p-1 mb-5">
            {(['signin', 'signup'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => { setMode(m); setErrors({}); setInfo(''); }}
                className={`h-11 rounded-xl font-semibold transition ${mode === m ? 'bg-card shadow-sm text-ink' : 'text-muted'}`}
              >
                {m === 'signin' ? t('signIn') : t('signUp')}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-3" noValidate>
            <div>
              <div className="relative">
                <Mail className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
                <input
                  type="email"
                  autoComplete="email"
                  className={`${inputCls} ps-12 ${errors.email ? 'border-danger' : ''}`}
                  placeholder={t('email')}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  dir="ltr"
                />
              </div>
              {errors.email && <p className="mt-1.5 text-sm text-danger font-medium">{errors.email}</p>}
            </div>
            <div>
              <div className="relative">
                <Lock className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
                <input
                  type="password"
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  className={`${inputCls} ps-12 ${errors.password ? 'border-danger' : ''}`}
                  placeholder={t('password')}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  dir="ltr"
                />
              </div>
              {errors.password && <p className="mt-1.5 text-sm text-danger font-medium">{errors.password}</p>}
            </div>
            {errors.form && <p className="rounded-xl bg-danger-soft text-danger px-3 py-2 text-sm font-medium">{errors.form}</p>}
            {info && <p className="rounded-xl bg-brand-soft text-brand px-3 py-2 text-sm font-medium">{info}</p>}
            <button type="submit" disabled={busy} className={`${primaryBtn} w-full`}>
              {busy && <Spinner />} {mode === 'signin' ? t('signIn') : t('signUp')}
            </button>
          </form>

          <div className="flex items-center gap-3 my-4 text-muted text-sm">
            <div className="h-px flex-1 bg-line" /> {t('or')} <div className="h-px flex-1 bg-line" />
          </div>
          <button type="button" onClick={() => signInWithGoogle('OrderDesk')} className={`${secondaryBtn} w-full`}>
            <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden>
              <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
              <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
              <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
              <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
            </svg>
            {t('continueGoogle')}
          </button>

          <div className="mt-5 rounded-2xl border border-dashed border-accent/60 bg-accent-soft/60 p-3 text-sm flex items-center gap-3">
            <div className="flex-1 text-ink-2">
              <div className="font-semibold text-ink">Demo account</div>
              <div dir="ltr" className="text-start">{DEMO.email} · {DEMO.password}</div>
            </div>
            <button
              type="button"
              onClick={() => { setMode('signin'); setEmail(DEMO.email); setPassword(DEMO.password); }}
              className="h-10 px-3 rounded-xl bg-card border border-line font-semibold"
            >
              Fill
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

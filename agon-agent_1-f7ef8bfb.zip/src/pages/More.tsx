import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Download, LogOut, Package, Sparkles, Store, Smartphone } from 'lucide-react';
import supabase from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { CURRENCIES, LANGUAGES } from '../lib/format';
import { useInstallPrompt } from '../lib/pwa';
import type { Locale } from '../lib/types';
import UsageMeter from '../components/UsageMeter';
import { Card, Chip, PageHeader, SectionLabel, Spinner, inputCls, primaryBtn } from '../components/ui';

export default function More() {
  const { user } = useAuth();
  const { seller, refresh, t } = useSeller();
  const { canInstall, standalone, install } = useInstallPrompt();
  const [shopName, setShopName] = useState(seller?.shop_name ?? '');
  const [phone, setPhone] = useState(seller?.phone ?? '');
  const [currency, setCurrency] = useState(seller?.currency ?? 'USD');
  const [lang, setLang] = useState<Locale>(seller?.locale ?? 'en');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!seller) return;
    setShopName(seller.shop_name);
    setPhone(seller.phone ?? '');
    setCurrency(seller.currency);
    setLang(seller.locale);
  }, [seller]);

  const dirty = !!seller && (shopName !== seller.shop_name || phone !== (seller.phone ?? '') || currency !== seller.currency || lang !== seller.locale);

  const save = async () => {
    if (!shopName.trim()) return setError('Shop name can’t be empty.');
    setSaving(true);
    setError('');
    setMsg('');
    try {
      await api('/api/seller', { method: 'PUT', body: { shop_name: shopName, phone, currency, locale: lang } });
      await refresh();
      setMsg(t('saved'));
      setTimeout(() => setMsg(''), 2000);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title={t('more')} />
      <div className="p-4 space-y-4">
        <Card className="p-4">
          <SectionLabel icon={<Store className="h-4 w-4" />}>{t('shopDetails')}</SectionLabel>
          <div className="space-y-3">
            <div>
              <label className="text-sm text-muted">{t('shopName')}</label>
              <input className={`${inputCls} mt-1`} value={shopName} onChange={(e) => setShopName(e.target.value)} />
            </div>
            <div>
              <label className="text-sm text-muted">{t('shopPhone')}</label>
              <input className={`${inputCls} mt-1`} value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" dir="ltr" style={{ textAlign: 'start' }} />
            </div>
            <div>
              <label className="text-sm text-muted">{t('currency')}</label>
              <select className={`${inputCls} mt-1 appearance-none`} value={currency} onChange={(e) => setCurrency(e.target.value)}>
                {CURRENCIES.map((c) => <option key={c.code} value={c.code}>{c.code} — {c.label}</option>)}
              </select>
              {seller && currency !== seller.currency && (
                <p className="mt-1.5 text-xs text-muted">Existing orders keep the currency they were created in.</p>
              )}
            </div>
            <div>
              <label className="text-sm text-muted">{t('language')}</label>
              <div className="flex gap-2 mt-1">
                {LANGUAGES.map((l) => (
                  <Chip key={l.code} active={lang === l.code} onClick={() => setLang(l.code)} className="flex-1 justify-center h-12">{l.label}</Chip>
                ))}
              </div>
            </div>
            {error && <p className="text-danger text-sm font-medium">{error}</p>}
            <button type="button" onClick={save} disabled={!dirty || saving} className={`${primaryBtn} w-full`}>
              {saving && <Spinner />} {msg || t('save')}
            </button>
          </div>
        </Card>

        <Card className="p-4">
          <SectionLabel icon={<Sparkles className="h-4 w-4" />}>{t('plan')} · {seller?.plan === 'pro' ? t('proPlan') : t('freePlan')}</SectionLabel>
          <UsageMeter />
        </Card>

        <Card className="divide-y divide-line overflow-hidden">
          <Link to="/catalog" className="flex items-center gap-3 px-4 h-16 hover:bg-paper/60">
            <span className="h-10 w-10 grid place-items-center rounded-xl bg-accent-soft text-[#9A5B05]"><Package className="h-5 w-5" /></span>
            <span className="flex-1 font-semibold">{t('catalog')}</span>
            <ChevronRight className="h-5 w-5 text-muted rtl:rotate-180" />
          </Link>
          {!standalone && (
            canInstall ? (
              <button type="button" onClick={install} className="w-full flex items-center gap-3 px-4 h-16 hover:bg-paper/60 text-start">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-brand-soft text-brand"><Download className="h-5 w-5" /></span>
                <span className="flex-1 font-semibold">{t('installApp')}</span>
              </button>
            ) : (
              <div className="flex items-center gap-3 px-4 py-3">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-brand-soft text-brand"><Smartphone className="h-5 w-5" /></span>
                <div className="flex-1">
                  <div className="font-semibold">{t('installApp')}</div>
                  <div className="text-sm text-muted">{t('installHint')} On Android Chrome: menu → Install app.</div>
                </div>
              </div>
            )
          )}
          <button type="button" onClick={() => supabase.auth.signOut()} className="w-full flex items-center gap-3 px-4 h-16 hover:bg-danger-soft/50 text-start">
            <span className="h-10 w-10 grid place-items-center rounded-xl bg-danger-soft text-danger"><LogOut className="h-5 w-5" /></span>
            <span className="flex-1">
              <span className="block font-semibold text-danger">{t('signOut')}</span>
              <span className="block text-sm text-muted" dir="ltr" style={{ textAlign: 'start' }}>{user?.email}</span>
            </span>
          </button>
        </Card>
        <p className="text-center text-xs text-muted">OrderDesk · Phase 1 preview</p>
      </div>
    </div>
  );
}

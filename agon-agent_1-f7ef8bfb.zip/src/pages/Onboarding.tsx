import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Store, Phone } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { useAuth } from '../contexts/AuthContext';
import { api, errMsg } from '../lib/api';
import { CURRENCIES, LANGUAGES } from '../lib/format';
import type { Locale } from '../lib/types';
import { Chip, FullScreenLoader, Logo, Spinner, inputCls, primaryBtn } from '../components/ui';
import supabase from '../lib/supabase';

const REGION_CURRENCY: Record<string, string> = {
  PK: 'PKR', IN: 'INR', BD: 'BDT', AE: 'AED', SA: 'SAR', QA: 'QAR', KW: 'KWD', EG: 'EGP', NG: 'NGN', KE: 'KES',
  MY: 'MYR', ID: 'IDR', TR: 'TRY', GB: 'GBP', US: 'USD', DE: 'EUR', FR: 'EUR', IT: 'EUR', ES: 'EUR', NL: 'EUR', IE: 'EUR',
};

function guessCurrency() {
  const region = (navigator.language || '').split('-')[1]?.toUpperCase();
  return (region && REGION_CURRENCY[region]) || 'USD';
}

export default function Onboarding() {
  const { user } = useAuth();
  const { seller, loading, refresh, t, locale, setPreviewLocale } = useSeller();
  const navigate = useNavigate();
  const [shopName, setShopName] = useState('');
  const [phone, setPhone] = useState('');
  const [currency, setCurrency] = useState(guessCurrency);
  const [showAll, setShowAll] = useState(false);
  const [error, setError] = useState('');
  const [nameErr, setNameErr] = useState('');
  const [busy, setBusy] = useState(false);

  if (loading) return <FullScreenLoader />;
  if (seller) return <Navigate to="/" replace />;

  const visible = showAll ? CURRENCIES : CURRENCIES.slice(0, 8);
  if (!visible.find((c) => c.code === currency)) visible.push(CURRENCIES.find((c) => c.code === currency)!);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!shopName.trim()) return setNameErr('Add your shop name');
    setNameErr('');
    setBusy(true);
    setError('');
    try {
      await api('/api/seller', { method: 'POST', body: { shop_name: shopName, phone, currency, locale } });
      await refresh();
      navigate('/', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-dvh paper-bg">
      <form onSubmit={submit} className="mx-auto max-w-md px-5 pt-[max(env(safe-area-inset-top),24px)] pb-10" noValidate>
        <Logo size={48} />
        <h1 className="mt-5 font-display text-[32px] font-extrabold tracking-tight leading-tight">{t('welcome')}</h1>
        <p className="text-muted mt-1">{t('welcomeHint')}</p>
        <p className="text-xs text-muted mt-1" dir="ltr">{user?.email}</p>

        <div className="mt-7 space-y-6">
          <div>
            <label className="block font-semibold mb-2">1 · {t('shopName')}</label>
            <div className="relative">
              <Store className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
              <input className={`${inputCls} ps-12 ${nameErr ? 'border-danger' : ''}`} placeholder="e.g. Sweet Crumbs by Hina" value={shopName} onChange={(e) => setShopName(e.target.value)} autoFocus />
            </div>
            {nameErr && <p className="mt-1.5 text-sm text-danger font-medium">{nameErr}</p>}
            <div className="relative mt-3">
              <Phone className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
              <input className={`${inputCls} ps-12`} placeholder={t('shopPhone')} value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" dir="ltr" style={{ textAlign: 'start' }} />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-2">2 · {t('currency')}</label>
            <div className="grid grid-cols-4 gap-2">
              {visible.map((c) => (
                <button
                  type="button"
                  key={c.code}
                  title={c.label}
                  onClick={() => setCurrency(c.code)}
                  className={`h-12 rounded-2xl border font-bold transition active:scale-95 ${currency === c.code ? 'bg-ink text-paper border-ink' : 'bg-card border-line text-ink-2'}`}
                >
                  {c.code}
                </button>
              ))}
            </div>
            {!showAll && (
              <button type="button" onClick={() => setShowAll(true)} className="mt-2 text-sm font-semibold text-brand h-10">
                + {CURRENCIES.length - 8} more
              </button>
            )}
          </div>

          <div>
            <label className="block font-semibold mb-2">3 · {t('language')}</label>
            <div className="flex gap-2">
              {LANGUAGES.map((l) => (
                <Chip key={l.code} active={locale === l.code} onClick={() => setPreviewLocale(l.code as Locale)} className="flex-1 justify-center h-12">
                  {l.label}
                </Chip>
              ))}
            </div>
          </div>
        </div>

        {error && <p className="mt-5 rounded-xl bg-danger-soft text-danger px-3 py-2 text-sm font-medium">{error}</p>}

        <button type="submit" disabled={busy} className={`${primaryBtn} w-full mt-8`}>
          {busy && <Spinner />} {t('getStarted')}
        </button>
        <button type="button" onClick={() => supabase.auth.signOut()} className="w-full h-12 mt-2 text-muted font-semibold">
          {t('signOut')}
        </button>
      </form>
    </div>
  );
}

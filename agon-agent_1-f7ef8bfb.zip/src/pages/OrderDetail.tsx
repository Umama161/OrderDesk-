import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarDays, CheckCircle2, Copy, MapPin, Phone, Plus, StickyNote, Trash2, X, MessageCircle, Receipt } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { balanceOf, dateLabel, money, payState, timeAgo } from '../lib/format';
import { buildConfirmation, whatsappLink } from '../lib/confirmation';
import type { Order, OrderStatus } from '../lib/types';
import PaymentSheet from '../components/PaymentSheet';
import { Avatar, Card, ErrorBox, PageHeader, PayBadge, SectionLabel, Spinner, secondaryBtn } from '../components/ui';

const STATUSES: OrderStatus[] = ['new', 'confirmed', 'delivered', 'cancelled'];

export default function OrderDetail() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const { t, locale, seller, refresh } = useSeller();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionError, setActionError] = useState('');
  const [sheet, setSheet] = useState(false);
  const [copied, setCopied] = useState(false);
  const [busyStatus, setBusyStatus] = useState<OrderStatus | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [removingPay, setRemovingPay] = useState<number | null>(null);
  const isNew = params.get('new') === '1';

  const fetchOrder = async () => {
    try {
      setError('');
      const data = await api<Order>(`/api/orders?id=${id}`);
      setOrder(data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrder();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const message = useMemo(() => (order && seller ? buildConfirmation(order, seller) : ''), [order, seller]);

  if (loading) {
    return (
      <div>
        <PageHeader title={t('order')} back="/" />
        <div className="p-4 space-y-3">
          {[120, 200, 160].map((h) => <div key={h} className="rounded-3xl bg-card border border-line animate-pulse" style={{ height: h }} />)}
        </div>
      </div>
    );
  }
  if (error || !order) {
    return (
      <div>
        <PageHeader title={t('order')} back="/" />
        <div className="p-4"><ErrorBox message={error || 'Order not found.'} onRetry={fetchOrder} /></div>
      </div>
    );
  }

  const cur = order.currency;
  const fm = (n: number) => money(n, cur, locale);
  const bal = balanceOf(order);
  const customer = order.customers;

  const setStatus = async (status: OrderStatus) => {
    if (status === order.status) return;
    setBusyStatus(status);
    setActionError('');
    try {
      await api('/api/orders', { method: 'PUT', body: { id: order.id, status } });
      await fetchOrder();
    } catch (e) {
      setActionError(errMsg(e));
    } finally {
      setBusyStatus(null);
    }
  };

  const markConfirmed = () => {
    if (order.status === 'new') setStatus('confirmed');
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      markConfirmed();
    } catch {
      setActionError('Copy failed — select the message text and copy it manually.');
    }
  };

  const removePayment = async (pid: number) => {
    if (removingPay !== pid) {
      setRemovingPay(pid);
      setTimeout(() => setRemovingPay((cur) => (cur === pid ? null : cur)), 3000);
      return;
    }
    try {
      await api('/api/payments', { method: 'DELETE', body: { id: pid } });
      setRemovingPay(null);
      await fetchOrder();
    } catch (e) {
      setActionError(errMsg(e));
    }
  };

  const deleteOrder = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      setTimeout(() => setConfirmDelete(false), 3500);
      return;
    }
    setDeleting(true);
    try {
      await api('/api/orders', { method: 'DELETE', body: { id: order.id } });
      await refresh();
      navigate('/', { replace: true });
    } catch (e) {
      setActionError(errMsg(e));
      setDeleting(false);
    }
  };

  const statusLabel: Record<OrderStatus, string> = {
    new: t('statusNew'),
    confirmed: t('statusConfirmed'),
    delivered: t('statusDelivered'),
    cancelled: t('statusCancelled'),
  };

  return (
    <div>
      <PageHeader title={`${t('order')} #${order.order_number}`} subtitle={timeAgo(order.created_at, locale)} back="/" right={<PayBadge state={payState(order)} />} />

      <div className="p-4 space-y-4">
        <AnimatePresence>
          {isNew && (
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, height: 0 }}
              className="rounded-2xl bg-brand text-white px-4 py-3 flex items-center gap-3"
            >
              <CheckCircle2 className="h-6 w-6 shrink-0 text-accent" />
              <span className="flex-1 font-semibold">{t('orderSaved')}</span>
              <button type="button" onClick={() => setParams({}, { replace: true })} className="h-9 w-9 grid place-items-center rounded-full hover:bg-white/10" aria-label="Dismiss">
                <X className="h-5 w-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {actionError && <ErrorBox message={actionError} />}

        {/* Confirmation first when the order is new — the 30-second flow */}
        <Card className={`p-4 ${isNew ? 'ring-4 ring-accent/40' : ''}`}>
          <SectionLabel icon={<MessageCircle className="h-4 w-4" />}>{t('confirmation')}</SectionLabel>
          <div className="rounded-2xl bg-[#EFE7DC] p-3">
            <div className="ms-auto max-w-[92%] rounded-2xl rounded-se-md bg-[#DCF8C6] px-3.5 py-2.5 text-[14.5px] leading-relaxed whitespace-pre-wrap text-ink shadow-sm" dir="auto">
              {message}
            </div>
          </div>
          <div className="grid grid-cols-[1fr_auto] gap-2 mt-3">
            <a
              href={whatsappLink(customer?.phone, message, cur)}
              target="_blank"
              rel="noreferrer"
              onClick={markConfirmed}
              className="inline-flex items-center justify-center gap-2 h-14 rounded-2xl bg-whatsapp text-white text-[17px] font-semibold active:scale-[0.98] transition hover:brightness-95"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden><path d="M17.5 14.4c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.3-1.4-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3zM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4c-1-1.6-1.5-3.4-1.5-5.2C2.2 6.6 6.6 2.2 12 2.2c2.6 0 5.1 1 6.9 2.9 1.8 1.8 2.9 4.3 2.9 6.9 0 5.4-4.4 9.8-9.8 9.8zm8.4-18.2C18.1 1.3 15.1 0 12 0 5.5 0 .2 5.3.2 11.8c0 2.1.5 4.1 1.6 5.9L0 24l6.4-1.7c1.7.9 3.7 1.4 5.6 1.4 6.5 0 11.8-5.3 11.8-11.8 0-3.1-1.2-6.1-3.4-8.3z" /></svg>
              {t('sendWhatsApp')}
            </a>
            <button type="button" onClick={copy} className={`${secondaryBtn} min-w-[96px]`}>
              {copied ? <CheckCircle2 className="h-5 w-5 text-brand" /> : <Copy className="h-5 w-5" />}
              {copied ? t('copied') : t('copy')}
            </button>
          </div>
        </Card>

        {/* Customer */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <Avatar name={customer?.name || '?'} size={52} />
            <div className="flex-1 min-w-0">
              <div className="font-display text-xl font-bold truncate">{customer?.name || '—'}</div>
              {customer?.phone && <div className="text-muted" dir="ltr" style={{ textAlign: 'start' }}>{customer.phone}</div>}
            </div>
            {customer?.phone && (
              <a href={`tel:${customer.phone}`} className="h-12 w-12 grid place-items-center rounded-2xl bg-brand-soft text-brand active:scale-95 transition" aria-label={t('call')}>
                <Phone className="h-5 w-5" />
              </a>
            )}
          </div>
        </Card>

        {/* Status */}
        <Card className="p-4">
          <SectionLabel>{t('status')}</SectionLabel>
          <div className="grid grid-cols-4 gap-1 rounded-2xl bg-paper-2 p-1">
            {STATUSES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                disabled={!!busyStatus}
                className={`h-12 rounded-xl text-[13.5px] font-bold transition inline-flex items-center justify-center ${
                  order.status === s ? (s === 'cancelled' ? 'bg-danger text-white' : 'bg-card shadow-sm text-ink') : 'text-muted'
                }`}
              >
                {busyStatus === s ? <Spinner className="h-4 w-4" /> : statusLabel[s]}
              </button>
            ))}
          </div>
        </Card>

        {/* Items + totals */}
        <Card className="p-4">
          <SectionLabel icon={<Receipt className="h-4 w-4" />}>{t('items')}</SectionLabel>
          <ul className="divide-y divide-line">
            {(order.order_items || []).map((i) => (
              <li key={i.id} className="py-2.5 flex items-center gap-3">
                <span className="h-9 min-w-9 px-2 rounded-xl bg-paper-2 grid place-items-center font-bold">{Number(i.quantity)}×</span>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{i.name}</div>
                  <div className="text-sm text-muted">{fm(Number(i.unit_price))} {t('each')}</div>
                </div>
                <div className="font-semibold">{fm(Number(i.line_total))}</div>
              </li>
            ))}
          </ul>
          <div className="mt-2 pt-3 border-t-2 border-dashed border-line space-y-1.5">
            <Row label={t('total')} value={fm(order.total)} strong />
            <Row label={t('paid')} value={fm(order.amount_paid)} />
            <Row label={t('balance')} value={fm(bal)} tone={bal > 0 ? 'danger' : 'ok'} />
          </div>
        </Card>

        {/* Delivery */}
        {(order.delivery_date || order.delivery_address || order.notes) && (
          <Card className="p-4 space-y-3">
            {order.delivery_date && (
              <div className="flex items-center gap-3">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-accent-soft text-[#9A5B05]"><CalendarDays className="h-5 w-5" /></span>
                <div>
                  <div className="text-sm text-muted">{t('delivery')}</div>
                  <div className="font-semibold">{dateLabel(order.delivery_date, locale, { weekday: 'long', day: 'numeric', month: 'long' }).label}</div>
                </div>
              </div>
            )}
            {order.delivery_address && (
              <div className="flex items-center gap-3">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-brand-soft text-brand"><MapPin className="h-5 w-5" /></span>
                <div>
                  <div className="text-sm text-muted">{t('address')}</div>
                  <div className="font-semibold">{order.delivery_address}</div>
                </div>
              </div>
            )}
            {order.notes && (
              <div className="flex items-center gap-3">
                <span className="h-10 w-10 grid place-items-center rounded-xl bg-paper-2 text-ink-2"><StickyNote className="h-5 w-5" /></span>
                <div>
                  <div className="text-sm text-muted">{t('notes')}</div>
                  <div className="font-semibold">{order.notes}</div>
                </div>
              </div>
            )}
          </Card>
        )}

        {/* Payments */}
        <Card className="p-4">
          <SectionLabel>{t('payments')}</SectionLabel>
          {(order.payments || []).length === 0 ? (
            <p className="text-muted">{t('noPayments')}</p>
          ) : (
            <ul className="space-y-2">
              {(order.payments || []).map((p) => (
                <li key={p.id} className="flex items-center gap-3 rounded-2xl bg-paper/70 border border-line px-3 py-2.5">
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold">{fm(Number(p.amount))}</div>
                    <div className="text-sm text-muted truncate">
                      {t(p.method)} · {new Date(p.paid_at).toLocaleDateString(locale === 'en' ? 'en-GB' : locale, { day: 'numeric', month: 'short' })}
                      {p.note ? ` · ${p.note}` : ''}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removePayment(p.id)}
                    className={`h-10 px-3 rounded-xl text-sm font-semibold transition ${removingPay === p.id ? 'bg-danger text-white' : 'text-muted hover:bg-danger-soft hover:text-danger'}`}
                  >
                    {removingPay === p.id ? t('confirmDelete') : <Trash2 className="h-4 w-4" />}
                  </button>
                </li>
              ))}
            </ul>
          )}
          {bal > 0 && order.status !== 'cancelled' && (
            <button type="button" onClick={() => setSheet(true)} className={`${secondaryBtn} w-full mt-3 border-brand/40 text-brand`}>
              <Plus className="h-5 w-5" /> {t('recordPayment')}
            </button>
          )}
        </Card>

        {order.raw_message && (
          <details className="rounded-2xl border border-line bg-card/60 px-4 py-3 text-sm">
            <summary className="cursor-pointer font-semibold text-ink-2">{t('originalMessage')}</summary>
            <p className="mt-2 whitespace-pre-wrap text-muted">{order.raw_message}</p>
          </details>
        )}

        <button
          type="button"
          onClick={deleteOrder}
          disabled={deleting}
          className={`w-full h-13 rounded-2xl font-semibold inline-flex items-center justify-center gap-2 transition ${
            confirmDelete ? 'bg-danger text-white' : 'text-danger hover:bg-danger-soft'
          }`}
        >
          {deleting ? <Spinner /> : <Trash2 className="h-5 w-5" />}
          {confirmDelete ? t('confirmDelete') : t('deleteOrder')}
        </button>
      </div>

      <PaymentSheet open={sheet} onClose={() => setSheet(false)} orderId={order.id} balance={bal} currency={cur} onSaved={fetchOrder} />
    </div>
  );
}

function Row({ label, value, strong, tone }: { label: string; value: string; strong?: boolean; tone?: 'danger' | 'ok' }) {
  return (
    <div className="flex items-center justify-between">
      <span className={strong ? 'font-semibold' : 'text-muted'}>{label}</span>
      <span className={`${strong ? 'font-display text-xl font-bold' : 'font-semibold'} ${tone === 'danger' ? 'text-danger' : tone === 'ok' ? 'text-brand' : ''}`}>
        {value}
      </span>
    </div>
  );
}

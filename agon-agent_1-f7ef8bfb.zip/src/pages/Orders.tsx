import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CalendarDays, Search, Plus, X } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { balanceOf, dateLabel, localISO, money, payState } from '../lib/format';
import type { Order } from '../lib/types';
import UsageMeter from '../components/UsageMeter';
import { Avatar, Chip, ErrorBox, PayBadge, StatusBadge, Logo, primaryBtn } from '../components/ui';

type Filter = 'all' | 'unpaid' | 'upcoming' | 'delivered';

export default function Orders() {
  const { t, seller, refresh } = useSeller();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [q, setQ] = useState('');

  const fetchOrders = async () => {
    try {
      setError('');
      const data = await api<Order[]>('/api/orders');
      setOrders(data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const today = localISO();
  const isOpen = (o: Order) => o.status !== 'cancelled';
  const counts = useMemo(
    () => ({
      unpaid: orders.filter((o) => isOpen(o) && payState(o) !== 'paid').length,
      upcoming: orders.filter((o) => o.delivery_date && o.delivery_date >= today && o.status !== 'delivered' && isOpen(o)).length,
    }),
    [orders, today],
  );

  const filtered = useMemo(() => {
    let list = orders;
    const query = q.trim().toLowerCase();
    if (query) list = list.filter((o) => (o.customers?.name || '').toLowerCase().includes(query) || String(o.order_number).includes(query));
    if (filter === 'unpaid') list = list.filter((o) => isOpen(o) && payState(o) !== 'paid');
    if (filter === 'upcoming')
      list = list
        .filter((o) => o.delivery_date && o.delivery_date >= today && o.status !== 'delivered' && isOpen(o))
        .sort((a, b) => (a.delivery_date! < b.delivery_date! ? -1 : 1));
    if (filter === 'delivered') list = list.filter((o) => o.status === 'delivered');
    return list;
  }, [orders, q, filter, today]);

  return (
    <div>
      <header className="px-4 pt-[max(env(safe-area-inset-top),18px)] pb-2">
        <div className="flex items-center gap-3">
          <Logo size={36} />
          <div className="min-w-0">
            <div className="text-sm text-muted truncate">{seller?.shop_name}</div>
            <h1 className="font-display text-[28px] leading-none font-extrabold tracking-tight">{t('ordersTitle')}</h1>
          </div>
        </div>
        <div className="mt-4"><UsageMeter /></div>
        <div className="relative mt-3">
          <Search className="absolute start-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t('searchCustomers')}
            className="w-full h-12 rounded-2xl bg-card border border-line ps-12 pe-11 text-[16px] outline-none focus:border-brand focus:ring-4 focus:ring-brand/10"
          />
          {q && (
            <button type="button" onClick={() => setQ('')} className="absolute end-2 top-1/2 -translate-y-1/2 h-9 w-9 grid place-items-center rounded-full text-muted hover:bg-paper-2" aria-label="Clear">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </header>

      <div className="sticky top-0 z-10 bg-paper/90 backdrop-blur-md px-4 py-2.5 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 w-max">
          <Chip active={filter === 'all'} onClick={() => setFilter('all')}>{t('filterAll')}</Chip>
          <Chip active={filter === 'unpaid'} onClick={() => setFilter('unpaid')}>
            {t('filterUnpaid')}
            {counts.unpaid > 0 && <span className={`min-w-6 h-6 px-1.5 rounded-full text-xs grid place-items-center ${filter === 'unpaid' ? 'bg-danger text-white' : 'bg-danger-soft text-danger'}`}>{counts.unpaid}</span>}
          </Chip>
          <Chip active={filter === 'upcoming'} onClick={() => setFilter('upcoming')}>
            {t('filterUpcoming')}
            {counts.upcoming > 0 && <span className={`min-w-6 h-6 px-1.5 rounded-full text-xs grid place-items-center ${filter === 'upcoming' ? 'bg-accent text-ink' : 'bg-accent-soft text-[#9A5B05]'}`}>{counts.upcoming}</span>}
          </Chip>
          <Chip active={filter === 'delivered'} onClick={() => setFilter('delivered')}>{t('filterDelivered')}</Chip>
        </div>
      </div>

      <div className="px-4 pt-2 space-y-3">
        {error && <ErrorBox message={error} onRetry={fetchOrders} />}
        {loading &&
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-[112px] rounded-3xl bg-card border border-line animate-pulse" />
          ))}
        {!loading && !error && orders.length === 0 && (
          <div className="text-center py-12 px-6">
            <div className="mx-auto h-20 w-20 rounded-[28px] bg-accent-soft grid place-items-center text-4xl">💬</div>
            <h2 className="mt-4 font-display text-2xl font-bold">{t('noOrders')}</h2>
            <p className="mt-1 text-muted">{t('noOrdersHint')}</p>
            <Link to="/add" className={`${primaryBtn} mt-6`}><Plus className="h-5 w-5" /> {t('addFirstOrder')}</Link>
          </div>
        )}
        {!loading && orders.length > 0 && filtered.length === 0 && (
          <p className="text-center text-muted py-10">{t('noMatches')}</p>
        )}
        {filtered.map((o, i) => (
          <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.03 }}>
            <OrderCard order={o} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function OrderCard({ order: o }: { order: Order }) {
  const { t, locale } = useSeller();
  const name = o.customers?.name || '—';
  const summary = (o.order_items || []).map((i) => `${Number(i.quantity)}× ${i.name}`).join(', ');
  const bal = balanceOf(o);
  const d = o.delivery_date ? dateLabel(o.delivery_date, locale) : null;
  const done = o.status === 'delivered' || o.status === 'cancelled';
  return (
    <Link
      to={`/orders/${o.id}`}
      className={`block rounded-3xl bg-card border border-line p-4 shadow-card active:scale-[0.99] transition hover:border-ink/20 ${done ? 'opacity-70' : ''}`}
    >
      <div className="flex items-start gap-3">
        <Avatar name={name} />
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="font-semibold text-[17px] truncate">{name}</span>
            <span className="text-muted text-sm shrink-0">#{o.order_number}</span>
          </div>
          <div className="text-ink-2 text-[14px] truncate">{summary}</div>
        </div>
        <div className="text-end shrink-0">
          <div className="font-display font-bold text-[18px]">{money(o.total, o.currency, locale)}</div>
          {bal > 0 && o.status !== 'cancelled' && (
            <div className="text-[13px] text-danger font-semibold">{money(bal, o.currency, locale)} {t('due')}</div>
          )}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-1.5 ps-[56px]">
        {d && (
          <span
            className={`inline-flex items-center gap-1 h-7 px-2.5 rounded-full text-[13px] font-bold ${
              d.rel === 'today' && !done ? 'bg-accent text-ink' : d.rel === 'tomorrow' && !done ? 'bg-accent-soft text-[#9A5B05]' : 'bg-paper-2 text-ink-2'
            }`}
          >
            <CalendarDays className="h-3.5 w-3.5" />
            {d.rel === 'today' ? t('today') : d.rel === 'tomorrow' ? t('tomorrow') : d.label}
          </span>
        )}
        {o.status !== 'new' && <StatusBadge status={o.status} />}
        {o.status !== 'cancelled' && <PayBadge state={payState(o)} />}
      </div>
    </Link>
  );
}

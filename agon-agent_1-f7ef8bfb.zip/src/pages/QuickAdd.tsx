import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ClipboardPaste, Sparkles, PencilLine, X, Lock, AlertTriangle, Wand2 } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import { localISO } from '../lib/format';
import type { ParsedOrder, Product } from '../lib/types';
import OrderForm from '../components/OrderForm';
import { PageHeader, Spinner, primaryBtn, secondaryBtn } from '../components/ui';

const EXAMPLES = [
  'Ayesha wants 2 chocolate cakes and 1 box brownies, deliver Friday to F-7, will pay half now',
  'Salam! This is Bilal 0321 4567890. Need 3 dozen cupcakes for Sunday, address House 12 Street 5 G-11/2. Sent 1500 advance',
  'Order for Sana: 1 red velvet cake 2kg, tomorrow at DHA Phase 5, cash on delivery',
];

const EMPTY: ParsedOrder = { customer_name: '', phone: '', items: [], delivery_date: '', delivery_address: '', amount_paid: 0, notes: '' };

interface ParseResult {
  order: ParsedOrder;
  warnings: string[];
  source: 'claude' | 'rules';
  notice: string;
}

export default function QuickAdd() {
  const { t, usage } = useSeller();
  const [step, setStep] = useState<'paste' | 'review'>('paste');
  const [message, setMessage] = useState('');
  const [parsing, setParsing] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<ParseResult | null>(null);
  const [formKey, setFormKey] = useState(0);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    api<Product[]>('/api/products').then(setProducts).catch(() => setProducts([]));
  }, []);

  const limitReached = !!usage && usage.limit !== null && usage.used >= usage.limit;

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setMessage(text);
    } catch {
      setError('Your browser blocked clipboard access — long-press the box and choose Paste.');
    }
  };

  const read = async () => {
    if (!message.trim()) return setError('Paste a chat message first.');
    setParsing(true);
    setError('');
    try {
      const r = await api<ParseResult>('/api/parse', { method: 'POST', body: { message, today: localISO() } });
      setResult(r);
      setFormKey((k) => k + 1);
      setStep('review');
      window.scrollTo({ top: 0 });
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setParsing(false);
    }
  };

  const manual = () => {
    setResult({ order: EMPTY, warnings: [], source: 'rules', notice: '' });
    setMessage('');
    setFormKey((k) => k + 1);
    setStep('review');
  };

  if (limitReached) {
    return (
      <div>
        <PageHeader title={t('quickAdd')} back="/" />
        <div className="p-5">
          <div className="rounded-[28px] bg-ink text-paper p-6">
            <Lock className="h-8 w-8 text-accent" />
            <h2 className="mt-3 font-display text-2xl font-bold">{t('limitTitle')}</h2>
            <p className="mt-2 text-paper/70">{t('limitBody')}</p>
            <Link to="/upgrade" className={`${primaryBtn} w-full mt-6 bg-accent text-ink hover:bg-[#F5B957]`}>{t('upgrade')}</Link>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'review' && result) {
    const isManual = !message.trim();
    return (
      <div>
        <PageHeader
          title={isManual ? t('manualEntry') : t('quickAdd')}
          back
          right={
            !isManual ? (
              <button type="button" onClick={() => setStep('paste')} className="h-11 px-3 rounded-xl text-sm font-semibold text-brand hover:bg-brand-soft">
                <PencilLine className="h-4 w-4 inline -mt-0.5" /> Message
              </button>
            ) : undefined
          }
        />
        <div className="p-4 space-y-3">
          {!isManual && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className={`rounded-2xl px-4 py-3 flex items-start gap-3 ${result.source === 'claude' ? 'bg-brand text-white' : 'bg-accent-soft text-ink'}`}
            >
              {result.source === 'claude' ? <Sparkles className="h-5 w-5 mt-0.5 shrink-0" /> : <Wand2 className="h-5 w-5 mt-0.5 shrink-0" />}
              <div className="text-[15px]">
                <div className="font-semibold">{result.source === 'claude' ? t('readByAI') : t('readByRules')}</div>
                {result.notice && <div className="text-sm opacity-80">{result.notice}</div>}
                {result.warnings.length > 0 && (
                  <ul className="mt-1 text-sm opacity-90 space-y-0.5">
                    {result.warnings.map((w) => (
                      <li key={w} className="flex items-center gap-1.5"><AlertTriangle className="h-3.5 w-3.5" /> {w}</li>
                    ))}
                  </ul>
                )}
              </div>
            </motion.div>
          )}
          <OrderForm key={formKey} initial={result.order} products={products} rawMessage={message.trim()} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title={t('quickAdd')} back="/" />
      <div className="p-4">
        <h2 className="font-display text-[22px] font-bold">{t('pasteTitle')}</h2>
        <p className="text-muted mt-1 text-[15px]">{t('pasteHint')}</p>

        <div className="mt-4 rounded-[26px] bg-card border border-line shadow-card p-3 focus-within:border-brand focus-within:ring-4 focus-within:ring-brand/10 transition">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={6}
            placeholder={t('pastePlaceholder')}
            className="w-full resize-none bg-transparent outline-none text-[17px] leading-relaxed p-2 placeholder:text-muted/70"
          />
          <div className="flex items-center gap-2">
            <button type="button" onClick={pasteFromClipboard} className="h-11 px-4 rounded-xl bg-paper-2 font-semibold inline-flex items-center gap-2 active:scale-95 transition">
              <ClipboardPaste className="h-5 w-5" /> {t('pasteFromClipboard')}
            </button>
            {message && (
              <button type="button" onClick={() => setMessage('')} className="h-11 w-11 grid place-items-center rounded-xl text-muted hover:bg-paper-2" aria-label="Clear">
                <X className="h-5 w-5" />
              </button>
            )}
            <span className="ms-auto text-xs text-muted">{message.length}/4000</span>
          </div>
        </div>

        {error && <p className="mt-3 rounded-xl bg-danger-soft text-danger px-3 py-2 text-sm font-medium">{error}</p>}

        <button type="button" onClick={read} disabled={parsing} className={`${primaryBtn} w-full mt-4`}>
          {parsing ? <Spinner /> : <Sparkles className="h-5 w-5" />}
          {parsing ? t('reading') : t('readOrder')}
        </button>
        <button type="button" onClick={manual} className={`${secondaryBtn} w-full mt-2`}>
          <PencilLine className="h-5 w-5" /> {t('fillManually')}
        </button>

        <div className="mt-8">
          <div className="text-[13px] font-bold uppercase tracking-[0.08em] text-muted mb-3">{t('tryExample')}</div>
          <div className="space-y-2">
            {EXAMPLES.map((ex) => (
              <button
                type="button"
                key={ex}
                onClick={() => { setMessage(ex); setError(''); }}
                className="block w-full text-start rounded-2xl rounded-ss-md bg-[#DCF8C6]/70 border border-[#B9E6A0] px-4 py-3 text-[15px] text-ink-2 active:scale-[0.99] transition hover:bg-[#DCF8C6]"
              >
                {ex}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

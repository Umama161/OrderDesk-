import { useState } from 'react';
import { Check, Infinity as InfinityIcon, Lock, Sparkles, Info } from 'lucide-react';
import { useSeller } from '../contexts/SellerContext';
import { api, errMsg } from '../lib/api';
import UsageMeter from '../components/UsageMeter';
import { Card, PageHeader, Spinner, primaryBtn } from '../components/ui';

export default function Upgrade() {
  const { t, seller, usage } = useSeller();
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const isPro = seller?.plan === 'pro';
  const resets = usage?.resets_at ? new Date(usage.resets_at).toLocaleDateString(undefined, { day: 'numeric', month: 'long' }) : '';

  const checkout = async () => {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const r = await api<{ placeholder?: boolean; message?: string; url?: string }>('/api/checkout', { method: 'POST' });
      if (r.url) window.location.href = r.url;
      else setNotice(r.message || 'Checkout is not available yet.');
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const free = ['30 orders every month', 'Quick Add from chat messages', 'Payment tracking & confirmations'];
  const pro = ['Unlimited orders', 'Everything in Free'];

  return (
    <div>
      <PageHeader title={t('upgrade')} back />
      <div className="p-4 space-y-4">
        <div className="rounded-[28px] bg-ink text-paper p-6 relative overflow-hidden">
          <div className="absolute -end-8 -top-8 h-32 w-32 rounded-full bg-accent/90" />
          <InfinityIcon className="relative h-9 w-9 text-accent" />
          <h2 className="relative mt-3 font-display text-[30px] leading-tight font-extrabold">Never stop taking orders</h2>
          <p className="relative mt-2 text-paper/70">
            The free plan includes 30 orders a month{resets ? ` — your counter resets on ${resets}` : ''}. Pro removes the limit.
          </p>
        </div>

        <UsageMeter />

        <div className="grid gap-3">
          <Card className={`p-5 ${!isPro ? 'ring-2 ring-ink' : ''}`}>
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xl font-bold">{t('freePlan')}</h3>
              {!isPro && <span className="text-xs font-bold uppercase tracking-wider bg-ink text-paper rounded-full px-2.5 py-1">Current</span>}
            </div>
            <ul className="mt-3 space-y-2">
              {free.map((f) => <li key={f} className="flex items-center gap-2 text-ink-2"><Check className="h-4 w-4 text-brand" /> {f}</li>)}
            </ul>
          </Card>
          <Card className={`p-5 border-brand/40 bg-brand-soft/40 ${isPro ? 'ring-2 ring-brand' : ''}`}>
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xl font-bold inline-flex items-center gap-2"><Sparkles className="h-5 w-5 text-accent" /> {t('proPlan')}</h3>
              {isPro && <span className="text-xs font-bold uppercase tracking-wider bg-brand text-white rounded-full px-2.5 py-1">Current</span>}
            </div>
            <ul className="mt-3 space-y-2">
              {pro.map((f) => <li key={f} className="flex items-center gap-2 text-ink-2"><Check className="h-4 w-4 text-brand" /> {f}</li>)}
            </ul>
            {!isPro && (
              <button type="button" onClick={checkout} disabled={busy} className={`${primaryBtn} w-full mt-5`}>
                {busy ? <Spinner /> : <Lock className="h-5 w-5" />} Continue to checkout
              </button>
            )}
            <p className="mt-2 text-center text-xs text-muted">Secure payments by Stripe</p>
          </Card>
        </div>

        {notice && (
          <div className="rounded-2xl border border-accent/50 bg-accent-soft px-4 py-3 text-[15px] flex gap-3">
            <Info className="h-5 w-5 shrink-0 mt-0.5 text-[#9A5B05]" />
            <span>{notice}</span>
          </div>
        )}
        {error && <p className="rounded-xl bg-danger-soft text-danger px-3 py-2 text-sm font-medium">{error}</p>}
      </div>
    </div>
  );
}

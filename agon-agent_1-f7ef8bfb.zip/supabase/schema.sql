-- OrderDesk — Phase 1 schema (Supabase Postgres)
-- Run in Supabase SQL Editor on a fresh project. Safe to re-run.
-- Every table carries user_id = auth.users.id (stored as text) and is protected by RLS.

-- ── Sellers: one row per account ────────────────────────────────────────────
create table if not exists public.sellers (
  user_id     text primary key,                         -- auth.uid()::text
  shop_name   text not null,
  email       text,
  phone       text,
  currency    varchar(3) not null default 'USD',        -- ISO 4217
  locale      varchar(5) not null default 'en',         -- en | ur | ar (ur/ar render RTL)
  plan        text not null default 'free' check (plan in ('free','pro')),
  created_at  timestamptz not null default now()
);

-- ── Customers: auto-created from orders (matched by phone, then name) ──────
create table if not exists public.customers (
  id          serial primary key,
  user_id     text not null,
  name        text not null,
  phone       text,
  address     text,
  created_at  timestamptz not null default now()
);
create index if not exists customers_user_idx  on public.customers (user_id);
create index if not exists customers_phone_idx on public.customers (user_id, phone);

-- ── Products: seller catalog (Phase 1 read-only, used for price matching) ──
create table if not exists public.products (
  id          serial primary key,
  user_id     text not null,
  name        text not null,
  price       numeric not null default 0 check (price >= 0),
  unit        text,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);
create index if not exists products_user_idx on public.products (user_id);

-- ── Orders ──────────────────────────────────────────────────────────────────────
create table if not exists public.orders (
  id                serial primary key,
  user_id           text not null,
  customer_id       integer references public.customers(id) on delete set null,
  order_number      integer not null,                   -- per-seller, starts at 1001
  status            text not null default 'new'
                    check (status in ('new','confirmed','delivered','cancelled')),
  delivery_date     date,
  delivery_address  text,
  notes             text,
  raw_message       text,                               -- original pasted chat
  total             numeric not null default 0,
  amount_paid       numeric not null default 0,         -- denormalised sum(payments.amount)
  currency          varchar(3) not null default 'USD',  -- snapshot of seller currency
  created_at        timestamptz not null default now()
);
create index if not exists orders_user_created_idx on public.orders (user_id, created_at desc);
create index if not exists orders_user_delivery_idx on public.orders (user_id, delivery_date);
create unique index if not exists orders_user_number_uidx on public.orders (user_id, order_number);

-- ── Order items ────────────────────────────────────────────────────────────────
create table if not exists public.order_items (
  id          serial primary key,
  user_id     text not null,
  order_id    integer not null references public.orders(id) on delete cascade,
  product_id  integer references public.products(id) on delete set null,
  name        text not null,                            -- snapshot of item name
  quantity    numeric not null default 1 check (quantity > 0),
  unit_price  numeric not null default 0 check (unit_price >= 0),
  line_total  numeric not null default 0
);
create index if not exists order_items_order_idx on public.order_items (order_id);

-- ── Payments ────────────────────────────────────────────────────────────────────
create table if not exists public.payments (
  id          serial primary key,
  user_id     text not null,
  order_id    integer not null references public.orders(id) on delete cascade,
  amount      numeric not null check (amount > 0),
  method      text not null default 'cash'
              check (method in ('cash','bank','card','wallet','other')),
  note        text,
  paid_at     timestamptz not null default now()
);
create index if not exists payments_order_idx on public.payments (order_id);

-- ── Row Level Security: each seller sees only their own rows ───────────────
do $$
declare t text;
begin
  foreach t in array array['sellers','customers','products','orders','order_items','payments'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists %I on public.%I', t || '_own_rows', t);
    execute format(
      'create policy %I on public.%I for all using (auth.uid()::text = user_id) with check (auth.uid()::text = user_id)',
      t || '_own_rows', t
    );
  end loop;
end $$;

-- Note: the serverless API uses the service-role key (bypasses RLS) but verifies the
-- caller's JWT and filters every query by user_id. RLS is the second line of defence
-- for any direct client access with the anon key.
